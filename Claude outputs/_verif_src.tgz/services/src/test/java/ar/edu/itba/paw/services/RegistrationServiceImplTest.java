package ar.edu.itba.paw.services;

import ar.edu.itba.paw.model.Event;
import ar.edu.itba.paw.model.EventInvitation;
import ar.edu.itba.paw.model.Registration;
import ar.edu.itba.paw.model.RegistrationStatus;
import ar.edu.itba.paw.model.User;
import ar.edu.itba.paw.model.exception.EventNotFoundException;
import ar.edu.itba.paw.persistence.EventDao;
import ar.edu.itba.paw.persistence.EventInvitationDao;
import ar.edu.itba.paw.persistence.RegistrationDao;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.lenient;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class RegistrationServiceImplTest {

    private static final long EVENT_ID = 1;
    private static final String EMAIL = "  Test@Mail.com  ";
    private static final String NORMALIZED_EMAIL = "test@mail.com";
    private static final String NAME = "Ana";
    private static final String CREATOR_EMAIL = "creador@mail.com";
    // Quien se anota siempre esta logueado (ver EventController.rsvp()): el
    // service ya no recibe un email/nombre sueltos, recibe el User entero
    // (con su id, que es lo que ahora identifica la fila). USER_ID/CREATOR_ID/
    // OTHER_ID son ids de "utileria" para estos tests con mocks, no hace falta
    // que existan de verdad en ninguna base.
    private static final long USER_ID = 10;
    private static final long CREATOR_ID = 20;
    private static final long OTHER_ID = 30;
    private static final long ONE_DAY_MILLIS = 24L * 60 * 60 * 1000;

    @Mock
    private RegistrationDao mockRegistrationDao;
    @Mock
    private EventDao mockEventDao;
    // Idem: RegistrationServiceImpl le pregunta cuantas invitaciones por mail a un
    // evento privado siguen sin usar (cada una reserva un lugar) y si quien se
    // anota tiene una. Sin stubear, un mock devuelve 0 / vacio: "nadie invitado".
    @Mock
    private EventInvitationDao mockInvitationDao;
    // Avisos y bandeja: "disparar y olvidar" (void). No se testean aca: verificar
    // que se llamaron seria testear la implementacion de RegistrationServiceImpl,
    // no el contrato de RegistrationService.
    @Mock
    private NotificationService notificationService;
    @Mock
    private InboxService inboxService;

    private RegistrationServiceImpl registrationService;

    @Before
    public void setUp() {
        registrationService = new RegistrationServiceImpl(
                mockRegistrationDao, mockEventDao, notificationService, mockInvitationDao, inboxService);
        // En produccion lo resuelve Spring (@Autowired @Lazy, ver RegistrationServiceImpl):
        // aca no hay proxy, asi que "el propio proxy" es directamente la instancia real.
        registrationService.self = registrationService;
    }

    private static User someUser() {
        final User user = new User(EMAIL, NAME);
        user.setId(USER_ID);
        return user;
    }

    private static Event eventWithCapacity(final Integer maxCapacity) {
        final Event event = new Event();
        event.setId(EVENT_ID);
        event.setMaxCapacity(maxCapacity);
        // register() y cancel() preguntan si el evento ya paso: por defecto, es de manana.
        event.setEventDate(new java.util.Date(System.currentTimeMillis() + ONE_DAY_MILLIS));
        return event;
    }

    private static Event finishedEvent() {
        final Event event = eventWithCapacity(null);
        event.setEventDate(new java.util.Date(System.currentTimeMillis() - ONE_DAY_MILLIS));
        return event;
    }

    private static Event eventRequiringApproval(final Integer maxCapacity) {
        final Event event = eventWithCapacity(maxCapacity);
        event.setCreatorEmail(CREATOR_EMAIL);
        event.setCreatorId(CREATOR_ID);
        event.setRequiresApproval(true);
        return event;
    }

    // El service guarda la inscripcion con el email normalizado, el id del usuario y el estado que
    // corresponde: si alguno no coincide, este stub no matchea y la inscripcion no se guarda.
    private void createdAs(final RegistrationStatus status) {
        when(mockRegistrationDao.create(argThat(registration -> registration.getStatus() == status
                && registration.getEventId() == EVENT_ID
                && NORMALIZED_EMAIL.equals(registration.getEmail())
                && Long.valueOf(USER_ID).equals(registration.getUserId()))))
                .thenReturn(new Registration(EVENT_ID, NORMALIZED_EMAIL, NAME, status));
    }

    // ---- register() ----

    @Test
    public void testRegisterReturnsAlreadyRegisteredWhenTheEmailIsAlreadyInThatEvent() {
        // Arrange
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventWithCapacity(10)));
        final Registration existing = new Registration(EVENT_ID, NORMALIZED_EMAIL, NAME, RegistrationStatus.CONFIRMED);
        when(mockRegistrationDao.findByEventAndUserId(EVENT_ID, USER_ID)).thenReturn(Optional.of(existing));

        // Act
        final RegistrationResult result = registrationService.register(EVENT_ID, someUser());

        // Assert
        assertEquals(RegistrationResult.Status.ALREADY_REGISTERED, result.getStatus());
    }

    @Test(expected = EventNotFoundException.class)
    public void testRegisterWithNonexistentEventThrowsEventNotFoundException() {
        // Arrange
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.empty());

        // Act
        registrationService.register(EVENT_ID, someUser());

        // Assert: la excepcion esperada en @Test(expected=...) ES el assert.
    }

    @Test
    public void testRegisterWhenTheEventAlreadyHappenedReturnsFinished() {
        // Arrange
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(finishedEvent()));

        // Act
        final RegistrationResult result = registrationService.register(EVENT_ID, someUser());

        // Assert: no se creo ninguna inscripcion (sin stub de create(), un create() devolveria null y romperia)
        assertEquals(RegistrationResult.Status.FINISHED, result.getStatus());
        assertFalse(result.isNotificationSent());
    }

    @Test
    public void testRegisterWhenTheEventIsFullReturnsWaitlisted() {
        // Arrange
        when(mockRegistrationDao.findByEventAndUserId(EVENT_ID, USER_ID)).thenReturn(Optional.empty());
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventWithCapacity(2)));
        when(mockRegistrationDao.countConfirmed(EVENT_ID)).thenReturn(2L);

        createdAs(RegistrationStatus.WAITLISTED);
        // Act
        final RegistrationResult result = registrationService.register(EVENT_ID, someUser());

        // Assert
        assertEquals(RegistrationResult.Status.WAITLISTED, result.getStatus());
        // Ya estaba lleno antes de esta inscripcion: no hay nada nuevo que anunciar.
        assertFalse(result.isNotificationSent());
    }

    @Test
    public void testRegisterWhenAlreadyOnTheWaitlistReturnsAlreadyWaitlisted() {
        // Arrange
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventWithCapacity(10)));
        final Registration existing = new Registration(EVENT_ID, NORMALIZED_EMAIL, NAME, RegistrationStatus.WAITLISTED);
        when(mockRegistrationDao.findByEventAndUserId(EVENT_ID, USER_ID)).thenReturn(Optional.of(existing));

        // Act
        final RegistrationResult result = registrationService.register(EVENT_ID, someUser());

        // Assert
        assertEquals(RegistrationResult.Status.ALREADY_WAITLISTED, result.getStatus());
    }

    @Test
    public void testRegisterWithFreeSpotReturnsConfirmed() {
        // Arrange
        when(mockRegistrationDao.findByEventAndUserId(EVENT_ID, USER_ID)).thenReturn(Optional.empty());
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventWithCapacity(2)));
        when(mockRegistrationDao.countConfirmed(EVENT_ID)).thenReturn(0L);

        createdAs(RegistrationStatus.CONFIRMED);
        // Act
        final RegistrationResult result = registrationService.register(EVENT_ID, someUser());

        // Assert
        assertEquals(RegistrationResult.Status.CONFIRMED, result.getStatus());
        // Quedo lugar libre (1 de 2): no se disparo el aviso de "evento lleno".
        assertFalse(result.isNotificationSent());
    }

    @Test
    public void testRegisterWhenConfirmingFillsTheLastSpotMarksNotificationSent() {
        // Arrange
        when(mockRegistrationDao.findByEventAndUserId(EVENT_ID, USER_ID)).thenReturn(Optional.empty());
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventWithCapacity(2)));
        // Antes de esta inscripcion habia 1 de 2 (no esta lleno); despues de
        // crearla, el segundo chequeo (post-insert) ya ve 2 de 2 (lleno).
        when(mockRegistrationDao.countConfirmed(EVENT_ID)).thenReturn(1L, 2L);

        createdAs(RegistrationStatus.CONFIRMED);
        // Act
        final RegistrationResult result = registrationService.register(EVENT_ID, someUser());

        // Assert
        assertEquals(RegistrationResult.Status.CONFIRMED, result.getStatus());
        // Esta inscripcion ocupo el ultimo lugar: se disparo notifyEventFull().
        // Sin verify(): se confirma por el valor de retorno, no espiando el mock.
        assertTrue(result.isNotificationSent());
    }

    @Test
    public void testRegisterWithUnlimitedCapacityNeverThrowsEvenIfManyAreConfirmed() {
        // Arrange
        when(mockRegistrationDao.findByEventAndUserId(EVENT_ID, USER_ID)).thenReturn(Optional.empty());
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventWithCapacity(null)));

        createdAs(RegistrationStatus.CONFIRMED);
        // Act
        final RegistrationResult result = registrationService.register(EVENT_ID, someUser());

        // Assert
        assertEquals(RegistrationResult.Status.CONFIRMED, result.getStatus());
    }

    // ---- register(): el creador no se anota a su propio evento ----

    @Test
    public void testRegisterReturnsOwnEventWhenTheCreatorTriesToRegister() {
        // Arrange
        final Event ownEvent = eventWithCapacity(10);
        ownEvent.setCreatorId(USER_ID);
        when(mockRegistrationDao.findByEventAndUserId(EVENT_ID, USER_ID)).thenReturn(Optional.empty());
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(ownEvent));

        // Act
        final RegistrationResult result = registrationService.register(EVENT_ID, someUser());

        // Assert
        assertEquals(RegistrationResult.Status.OWN_EVENT, result.getStatus());
    }

    @Test
    public void testRegisterDoesNotCreateOrNotifyWhenTheCreatorTriesToRegister() {
        // Arrange
        final Event ownEvent = eventWithCapacity(10);
        ownEvent.setCreatorId(USER_ID);
        when(mockRegistrationDao.findByEventAndUserId(EVENT_ID, USER_ID)).thenReturn(Optional.empty());
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(ownEvent));

        // Act
        final RegistrationResult result = registrationService.register(EVENT_ID, someUser());

        // Assert
        // OWN_EVENT solo se devuelve ANTES de crear la inscripcion o notificar a
        // nadie (early return): el resultado ya prueba que nada de eso paso.
        assertEquals(RegistrationResult.Status.OWN_EVENT, result.getStatus());
    }

    // ---- register() con requiresApproval ----

    @Test
    public void testRegisterOnEventRequiringApprovalReturnsPending() {
        // Arrange
        when(mockRegistrationDao.findByEventAndUserId(EVENT_ID, USER_ID)).thenReturn(Optional.empty());
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventRequiringApproval(10)));
        when(mockRegistrationDao.countConfirmed(EVENT_ID)).thenReturn(0L);

        createdAs(RegistrationStatus.PENDING);
        // Act
        final RegistrationResult result = registrationService.register(EVENT_ID, someUser());

        // Assert
        assertEquals(RegistrationResult.Status.PENDING, result.getStatus());
        // Queda pendiente de aprobacion: no ocupa lugar, asi que no se lleno nada.
        assertFalse(result.isNotificationSent());
    }

    // Sin cupo, la lista de espera gana: no tiene sentido "esperando revision"
    // para un lugar que ni siquiera existe.
    @Test
    public void testRegisterOnFullEventRequiringApprovalReturnsWaitlistedNotPending() {
        // Arrange
        when(mockRegistrationDao.findByEventAndUserId(EVENT_ID, USER_ID)).thenReturn(Optional.empty());
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventRequiringApproval(1)));
        when(mockRegistrationDao.countConfirmed(EVENT_ID)).thenReturn(1L);

        createdAs(RegistrationStatus.WAITLISTED);
        // Act
        final RegistrationResult result = registrationService.register(EVENT_ID, someUser());

        // Assert
        assertEquals(RegistrationResult.Status.WAITLISTED, result.getStatus());
        // Ya estaba lleno: va a la espera y no se vuelve a anunciar que se lleno.
        assertFalse(result.isNotificationSent());
    }

    @Test
    public void testRegisterWhenAlreadyPendingReturnsAlreadyPending() {
        // Arrange
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventWithCapacity(10)));
        final Registration existing = new Registration(EVENT_ID, NORMALIZED_EMAIL, NAME, RegistrationStatus.PENDING);
        when(mockRegistrationDao.findByEventAndUserId(EVENT_ID, USER_ID)).thenReturn(Optional.of(existing));

        // Act
        final RegistrationResult result = registrationService.register(EVENT_ID, someUser());

        // Assert
        assertEquals(RegistrationResult.Status.ALREADY_PENDING, result.getStatus());
    }

    @Test
    public void testRegisterWhenPreviouslyRejectedReturnsRejected() {
        // Arrange
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventWithCapacity(10)));
        final Registration existing = new Registration(EVENT_ID, NORMALIZED_EMAIL, NAME, RegistrationStatus.REJECTED);
        when(mockRegistrationDao.findByEventAndUserId(EVENT_ID, USER_ID)).thenReturn(Optional.of(existing));

        // Act
        final RegistrationResult result = registrationService.register(EVENT_ID, someUser());

        // Assert
        assertEquals(RegistrationResult.Status.REJECTED, result.getStatus());
    }

    /**
     * El criterio de cupo: solo cuentan los confirmados (y las invitaciones a un
     * evento privado). Los pedidos pendientes de aprobacion NO ocupan lugar: el
     * organizador los mira a todos y acepta hasta que se llene.
     */
    @Test
    public void testIsFullDoesNotCountPendingApprovals() {
        // Arrange
        when(mockEventDao.findById(EVENT_ID)).thenReturn(Optional.of(eventWithCapacity(2)));
        when(mockRegistrationDao.countConfirmed(EVENT_ID)).thenReturn(1L);
        // Hay muchos pendientes: si isFull() los contara, el evento daria "lleno".
        lenient().when(mockRegistrationDao.countPending(EVENT_ID)).thenReturn(5L);

        // Act
        final boolean result = registrationService.isFull(EVENT_ID);

        // Assert
        assertFalse(result);
    }

    // Con la mitad de los lugares confirmados, seguir aceptando pedidos pendientes
    // (aunque haya mas pedidos que lugares) esta permitido: nacen PENDING.
    @Test
    public void testRegisterOnApprovalEventWithMorePendingThanSpotsStillCreatesPending() {
        // Arrange
        when(mockRegistrationDao.findByEventAndUserId(EVENT_ID, USER_ID)).thenReturn(Optional.empty());
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventRequiringApproval(2)));
        when(mockRegistrationDao.countConfirmed(EVENT_ID)).thenReturn(1L);

        createdAs(RegistrationStatus.PENDING);
        // Act
        final RegistrationResult result = registrationService.register(EVENT_ID, someUser());

        // Assert
        assertEquals(RegistrationResult.Status.PENDING, result.getStatus());
        // Pendiente no ocupa lugar: aunque haya mas pedidos que lugares, no se lleno nada.
        assertFalse(result.isNotificationSent());
    }

    // ---- avisos en la bandeja ----

    private static Event eventWithCreator(final Integer maxCapacity) {
        final Event event = eventWithCapacity(maxCapacity);
        event.setCreatorEmail(CREATOR_EMAIL);
        event.setCreatorId(CREATOR_ID);
        return event;
    }

    // ---- isFull() ----

    @Test
    public void testIsFullReturnsTrueWhenConfirmedCountReachesCapacity() {
        // Arrange
        when(mockEventDao.findById(EVENT_ID)).thenReturn(Optional.of(eventWithCapacity(2)));
        when(mockRegistrationDao.countConfirmed(EVENT_ID)).thenReturn(2L);

        // Act
        final boolean result = registrationService.isFull(EVENT_ID);

        // Assert
        assertTrue(result);
    }

    @Test
    public void testIsFullReturnsFalseWhenThereIsStillRoom() {
        // Arrange
        when(mockEventDao.findById(EVENT_ID)).thenReturn(Optional.of(eventWithCapacity(2)));
        when(mockRegistrationDao.countConfirmed(EVENT_ID)).thenReturn(1L);

        // Act
        final boolean result = registrationService.isFull(EVENT_ID);

        // Assert
        assertFalse(result);
    }

    /**
     * EL TEST QUE IMPIDE SOBREVENDER. Con cupo 2, 1 confirmado y 1 invitacion a un
     * evento privado sin usar, el evento esta LLENO: cada invitacion reserva un
     * lugar. Si esto devolviera false, alguien de la calle se quedaria con el
     * lugar que le prometimos a quien invitamos.
     */
    @Test
    public void testIsFullCountsSpotsHeldByUnusedInvitations() {
        // Arrange
        when(mockEventDao.findById(EVENT_ID)).thenReturn(Optional.of(eventWithCapacity(2)));
        when(mockRegistrationDao.countConfirmed(EVENT_ID)).thenReturn(1L);
        when(mockInvitationDao.countOutstanding(EVENT_ID)).thenReturn(1L);

        // Act
        final boolean result = registrationService.isFull(EVENT_ID);

        // Assert
        assertTrue(result);
    }

    @Test
    public void testAvailableSpotsDiscountsSpotsHeldByUnusedInvitations() {
        // Arrange
        when(mockEventDao.findById(EVENT_ID)).thenReturn(Optional.of(eventWithCapacity(10)));
        when(mockRegistrationDao.countConfirmed(EVENT_ID)).thenReturn(7L);
        when(mockInvitationDao.countOutstanding(EVENT_ID)).thenReturn(2L);

        // Act
        final Integer result = registrationService.availableSpots(EVENT_ID);

        // Assert
        // 10 - 7 confirmados - 2 invitaciones = 1. Es el numero que ve la gente en
        // pantalla: si mostrara 3, tres personas creerian que hay lugar.
        assertEquals(Integer.valueOf(1), result);
    }

    @Test
    public void testRegisterGoesToTheWaitlistWhenTheLastSpotIsHeldByAnInvitation() {
        // Arrange
        when(mockRegistrationDao.findByEventAndUserId(EVENT_ID, USER_ID)).thenReturn(Optional.empty());
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventWithCapacity(2)));
        when(mockRegistrationDao.countConfirmed(EVENT_ID)).thenReturn(1L);
        when(mockInvitationDao.countOutstanding(EVENT_ID)).thenReturn(1L);

        // Act
        final RegistrationResult result = registrationService.register(EVENT_ID, someUser());

        // Assert
        assertEquals(RegistrationResult.Status.WAITLISTED, result.getStatus());
        // El ultimo lugar lo tiene una invitacion: va a la espera, no completo el cupo.
        assertFalse(result.isNotificationSent());
    }

    // La persona invitada usa el lugar que ya tenia reservado: para ella el evento
    // no esta lleno, aunque confirmados + invitaciones lleguen al cupo justo.
    @Test
    public void testRegisterWithAnInvitationTakesItsReservedSpotAndIsConfirmed() {
        // Arrange
        when(mockRegistrationDao.findByEventAndUserId(EVENT_ID, USER_ID)).thenReturn(Optional.empty());
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventWithCapacity(2)));
        when(mockRegistrationDao.countConfirmed(EVENT_ID)).thenReturn(1L);
        when(mockInvitationDao.countOutstanding(EVENT_ID)).thenReturn(1L);
        when(mockInvitationDao.findByEventAndUserId(EVENT_ID, USER_ID))
                .thenReturn(Optional.of(new EventInvitation(EVENT_ID, NORMALIZED_EMAIL, CREATOR_EMAIL)));

        // Act
        final RegistrationResult result = registrationService.register(EVENT_ID, someUser());

        // Assert
        assertEquals(RegistrationResult.Status.CONFIRMED, result.getStatus());
    }

    // Quien fue invitado ya fue elegido por el organizador: no vuelve a pedirle aprobacion.
    @Test
    public void testRegisterWithAnInvitationSkipsTheApprovalStep() {
        // Arrange
        when(mockRegistrationDao.findByEventAndUserId(EVENT_ID, USER_ID)).thenReturn(Optional.empty());
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventRequiringApproval(5)));
        when(mockInvitationDao.findByEventAndUserId(EVENT_ID, USER_ID))
                .thenReturn(Optional.of(new EventInvitation(EVENT_ID, NORMALIZED_EMAIL, CREATOR_EMAIL)));

        // Act
        final RegistrationResult result = registrationService.register(EVENT_ID, someUser());

        // Assert
        assertEquals(RegistrationResult.Status.CONFIRMED, result.getStatus());
    }

    @Test
    public void testIsFullForAnInvitedPersonIgnoresTheirOwnReservedSpot() {
        // Arrange
        when(mockEventDao.findById(EVENT_ID)).thenReturn(Optional.of(eventWithCapacity(2)));
        when(mockRegistrationDao.countConfirmed(EVENT_ID)).thenReturn(1L);
        when(mockInvitationDao.countOutstanding(EVENT_ID)).thenReturn(1L);
        when(mockInvitationDao.findByEventAndUserId(EVENT_ID, USER_ID))
                .thenReturn(Optional.of(new EventInvitation(EVENT_ID, NORMALIZED_EMAIL, CREATOR_EMAIL)));

        // Act
        final boolean result = registrationService.isFullFor(EVENT_ID, USER_ID);

        // Assert
        assertFalse(result);
    }

    @Test
    public void testIsFullReturnsFalseWhenCapacityIsUnlimited() {
        // Arrange
        when(mockEventDao.findById(EVENT_ID)).thenReturn(Optional.of(eventWithCapacity(null)));

        // Act
        final boolean result = registrationService.isFull(EVENT_ID);

        // Assert
        assertFalse(result);
    }

    @Test(expected = EventNotFoundException.class)
    public void testIsFullWithNonexistentEventThrowsEventNotFoundException() {
        // Arrange
        when(mockEventDao.findById(EVENT_ID)).thenReturn(Optional.empty());

        // Act
        registrationService.isFull(EVENT_ID);

        // Assert: la excepcion esperada en @Test(expected=...) ES el assert.
    }

    // ---- findByUserId() ----

    @Test
    public void testFindByUserIdDelegatesToTheDao() {
        // Arrange
        final List<Registration> registrations = Collections.singletonList(
                new Registration(EVENT_ID, NORMALIZED_EMAIL, NAME, RegistrationStatus.CONFIRMED));
        when(mockRegistrationDao.findByUserId(USER_ID)).thenReturn(registrations);

        // Act
        final List<Registration> result = registrationService.findByUserId(USER_ID);

        // Assert
        assertEquals(registrations, result);
    }

    // ---- cancel() ----

    @Test
    public void testCancelDeletesWhenTheUserOwnsTheRegistration() {
        // Arrange
        final Registration registration = new Registration(EVENT_ID, NORMALIZED_EMAIL, NAME, RegistrationStatus.CONFIRMED);
        registration.setId(5);
        registration.setUserId(USER_ID);
        when(mockRegistrationDao.findById(5)).thenReturn(Optional.of(registration));
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventWithCreator(10)));

        when(mockRegistrationDao.delete(5)).thenReturn(true);
        // Act
        final UnregisterResult result = registrationService.cancel(5, USER_ID);

        // Assert
        assertEquals(UnregisterResult.CANCELLED, result);
    }

    // Un rechazado / revocado no puede "darse de baja": si borrara su fila se saltearia
    // el rechazo (y podria volver a anotarse).
    @Test
    public void testCancelReturnsFinishedAndKeepsTheRowWhenTheEventAlreadyHappened() {
        // Arrange
        final Registration registration = new Registration(EVENT_ID, NORMALIZED_EMAIL, NAME, RegistrationStatus.CONFIRMED);
        registration.setId(5);
        registration.setUserId(USER_ID);
        when(mockRegistrationDao.findById(5)).thenReturn(Optional.of(registration));
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(finishedEvent()));

        // Act
        final UnregisterResult result = registrationService.cancel(5, USER_ID);

        // Assert: no se llamo a delete() (sin stub devolveria false y el resultado seria otro)
        assertEquals(UnregisterResult.FINISHED, result);
    }

    @Test
    public void testCancelReturnsRejectedAndKeepsTheRowWhenTheRegistrationWasRejected() {
        // Arrange
        final Registration registration = new Registration(EVENT_ID, NORMALIZED_EMAIL, NAME, RegistrationStatus.REJECTED);
        registration.setId(5);
        registration.setUserId(USER_ID);
        when(mockRegistrationDao.findById(5)).thenReturn(Optional.of(registration));
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventWithCreator(10)));

        // Act
        final UnregisterResult result = registrationService.cancel(5, USER_ID);

        // Assert
        assertEquals(UnregisterResult.REJECTED, result);
    }

    @Test
    public void testCancelReturnsNotFoundWhenTheRegistrationDoesNotExist() {
        // Arrange
        when(mockRegistrationDao.findById(5)).thenReturn(Optional.empty());

        // Act
        final UnregisterResult result = registrationService.cancel(5, USER_ID);

        // Assert
        assertEquals(UnregisterResult.NOT_FOUND, result);
    }

    @Test
    public void testCancelReturnsNotFoundWhenTheRegistrationBelongsToSomeoneElse() {
        // Arrange
        final Registration registration = new Registration(EVENT_ID, "otro@mail.com", NAME, RegistrationStatus.CONFIRMED);
        registration.setId(5);
        registration.setUserId(OTHER_ID);
        when(mockRegistrationDao.findById(5)).thenReturn(Optional.of(registration));

        // Act
        final UnregisterResult result = registrationService.cancel(5, USER_ID);

        // Assert
        assertEquals(UnregisterResult.NOT_FOUND, result);
    }

    // ---- findByEventAndUserId() ----

    @Test
    public void testFindByEventAndUserIdDelegatesToTheDao() {
        // Arrange
        final Registration registration = new Registration(EVENT_ID, NORMALIZED_EMAIL, NAME, RegistrationStatus.CONFIRMED);
        when(mockRegistrationDao.findByEventAndUserId(EVENT_ID, USER_ID)).thenReturn(Optional.of(registration));

        // Act
        final Optional<Registration> result = registrationService.findByEventAndUserId(EVENT_ID, USER_ID);

        // Assert
        assertTrue(result.isPresent());
        assertEquals(NORMALIZED_EMAIL, result.get().getEmail());
    }

    @Test
    public void testFindByEventAndUserIdReturnsEmptyWhenNotRegistered() {
        // Arrange
        when(mockRegistrationDao.findByEventAndUserId(EVENT_ID, USER_ID)).thenReturn(Optional.empty());

        // Act
        final Optional<Registration> result = registrationService.findByEventAndUserId(EVENT_ID, USER_ID);

        // Assert
        assertFalse(result.isPresent());
    }

    // ---- findByEventId() ----

    @Test
    public void testFindByEventIdDelegatesToTheDao() {
        // Arrange
        final List<Registration> registrations = Collections.singletonList(
                new Registration(EVENT_ID, NORMALIZED_EMAIL, NAME, RegistrationStatus.CONFIRMED));
        when(mockRegistrationDao.findByEventId(EVENT_ID)).thenReturn(registrations);

        // Act
        final List<Registration> result = registrationService.findByEventId(EVENT_ID);

        // Assert
        assertEquals(registrations, result);
    }

    // ---- findPendingByEvent() ----

    @Test
    public void testFindPendingByEventDelegatesToTheDaoWhenTheCreatorAsks() {
        // Arrange
        when(mockEventDao.findById(EVENT_ID)).thenReturn(Optional.of(eventRequiringApproval(null)));
        final List<Registration> pending = Collections.singletonList(
                new Registration(EVENT_ID, NORMALIZED_EMAIL, NAME, RegistrationStatus.PENDING));
        when(mockRegistrationDao.findPendingByEvent(EVENT_ID)).thenReturn(pending);

        // Act
        final List<Registration> result = registrationService.findPendingByEvent(EVENT_ID, CREATOR_ID);

        // Assert
        assertEquals(pending, result);
    }

    @Test
    public void testFindPendingByEventReturnsEmptyWhenAskedBySomeoneElse() {
        // Arrange
        when(mockEventDao.findById(EVENT_ID)).thenReturn(Optional.of(eventRequiringApproval(null)));
        // El dao SI tiene un pendiente: si el service lo consultara para cualquiera,
        // el resultado no estaria vacio.
        lenient().when(mockRegistrationDao.findPendingByEvent(EVENT_ID))
                .thenReturn(Collections.singletonList(pendingRegistration(5, NORMALIZED_EMAIL)));

        // Act
        final List<Registration> result = registrationService.findPendingByEvent(EVENT_ID, OTHER_ID);

        // Assert
        assertTrue(result.isEmpty());
    }

    @Test
    public void testFindPendingByEventReturnsEmptyWhenTheEventDoesNotExist() {
        // Arrange
        when(mockEventDao.findById(EVENT_ID)).thenReturn(Optional.empty());

        // Act
        final List<Registration> result = registrationService.findPendingByEvent(EVENT_ID, CREATOR_ID);

        // Assert
        assertTrue(result.isEmpty());
    }

    // ---- approve() ----

    private static Registration pendingRegistration(final long id, final String email) {
        final Registration registration = new Registration(EVENT_ID, email, NAME, RegistrationStatus.PENDING);
        registration.setId(id);
        return registration;
    }

    @Test
    public void testApproveConfirmsAPendingRegistrationOwnedByTheCreator() {
        // Arrange
        when(mockRegistrationDao.findById(5)).thenReturn(Optional.of(pendingRegistration(5, NORMALIZED_EMAIL)));
        when(mockEventDao.findById(EVENT_ID)).thenReturn(Optional.of(eventRequiringApproval(null)));
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventRequiringApproval(null)));

        when(mockRegistrationDao.updateStatus(5, RegistrationStatus.CONFIRMED)).thenReturn(true);
        // Act
        final ApprovalResult result = registrationService.approve(5, CREATOR_ID);

        // Assert
        assertEquals(ApprovalResult.Status.APPROVED, result.getStatus());
        // Sin tope de cupo el evento nunca se llena: no hay nada que anunciar.
        assertFalse(result.isNotificationSent());
    }

    @Test
    public void testApproveReturnsNotFoundWhenTheEventBelongsToSomeoneElse() {
        // Arrange
        when(mockRegistrationDao.findById(5)).thenReturn(Optional.of(pendingRegistration(5, NORMALIZED_EMAIL)));
        when(mockEventDao.findById(EVENT_ID)).thenReturn(Optional.of(eventRequiringApproval(null)));

        // Act
        final ApprovalResult result = registrationService.approve(5, OTHER_ID);

        // Assert
        assertEquals(ApprovalResult.Status.NOT_FOUND, result.getStatus());
    }

    @Test
    public void testApproveReturnsNotFoundWhenTheRegistrationIsNotPending() {
        // Arrange
        final Registration registration = new Registration(EVENT_ID, NORMALIZED_EMAIL, NAME, RegistrationStatus.CONFIRMED);
        registration.setId(5);
        when(mockRegistrationDao.findById(5)).thenReturn(Optional.of(registration));

        // Act
        final ApprovalResult result = registrationService.approve(5, CREATOR_ID);

        // Assert
        assertEquals(ApprovalResult.Status.NOT_FOUND, result.getStatus());
    }

    @Test
    public void testApproveReturnsNotFoundWhenTheRegistrationDoesNotExist() {
        // Arrange
        when(mockRegistrationDao.findById(5)).thenReturn(Optional.empty());

        // Act
        final ApprovalResult result = registrationService.approve(5, CREATOR_ID);

        // Assert
        assertEquals(ApprovalResult.Status.NOT_FOUND, result.getStatus());
    }

    // El organizador acepta hasta que se llena el cupo, y ni un pedido mas.
    @Test
    public void testApproveReturnsFullAndChangesNothingWhenThereIsNoRoomLeft() {
        // Arrange
        when(mockRegistrationDao.findById(5)).thenReturn(Optional.of(pendingRegistration(5, NORMALIZED_EMAIL)));
        when(mockEventDao.findById(EVENT_ID)).thenReturn(Optional.of(eventRequiringApproval(2)));
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventRequiringApproval(2)));
        when(mockRegistrationDao.countConfirmed(EVENT_ID)).thenReturn(2L);

        // Act
        final ApprovalResult result = registrationService.approve(5, CREATOR_ID);

        // Assert
        assertEquals(ApprovalResult.Status.FULL, result.getStatus());
    }

    // Las invitaciones por mail tambien ocupan lugar: no se puede aceptar a nadie
    // en el lugar que le prometimos a alguien invitado.
    @Test
    public void testApproveReturnsFullWhenTheLastSpotIsHeldByAnInvitation() {
        // Arrange
        when(mockRegistrationDao.findById(5)).thenReturn(Optional.of(pendingRegistration(5, NORMALIZED_EMAIL)));
        when(mockEventDao.findById(EVENT_ID)).thenReturn(Optional.of(eventRequiringApproval(2)));
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventRequiringApproval(2)));
        when(mockRegistrationDao.countConfirmed(EVENT_ID)).thenReturn(1L);
        when(mockInvitationDao.countOutstanding(EVENT_ID)).thenReturn(1L);

        // Act
        final ApprovalResult result = registrationService.approve(5, CREATOR_ID);

        // Assert
        assertEquals(ApprovalResult.Status.FULL, result.getStatus());
    }

    // Cuando esta aceptacion ocupa el ultimo lugar, el resto de los pendientes ya
    // no tiene a donde entrar: pasan solos a la lista de espera.
    @Test
    public void testApproveTakingTheLastSpotMovesTheRemainingPendingToTheWaitlist() {
        // Arrange
        when(mockRegistrationDao.findById(5)).thenReturn(Optional.of(pendingRegistration(5, NORMALIZED_EMAIL)));
        when(mockEventDao.findById(EVENT_ID)).thenReturn(Optional.of(eventRequiringApproval(2)));
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventRequiringApproval(2)));
        // Antes de aceptar quedaba 1 lugar (1 confirmado); despues, 2 de 2.
        when(mockRegistrationDao.countConfirmed(EVENT_ID)).thenReturn(1L, 2L);
        final Registration other = pendingRegistration(6, "otro@mail.com");
        when(mockRegistrationDao.findPendingByEvent(EVENT_ID)).thenReturn(Collections.singletonList(other));

        when(mockRegistrationDao.updateStatus(5, RegistrationStatus.CONFIRMED)).thenReturn(true);
        when(mockRegistrationDao.updateStatus(6, RegistrationStatus.WAITLISTED)).thenReturn(true);
        // Act
        final ApprovalResult result = registrationService.approve(5, CREATOR_ID);

        // Assert
        assertEquals(ApprovalResult.Status.APPROVED, result.getStatus());
        // Esta aceptacion ocupo el ultimo lugar: se disparo notifyEventFull().
        // Sin verify(): se confirma por el valor de retorno, no espiando el mock.
        assertTrue(result.isNotificationSent());
    }

    @Test
    public void testApproveWithSpotsStillLeftKeepsTheOtherRequestsPending() {
        // Arrange
        when(mockRegistrationDao.findById(5)).thenReturn(Optional.of(pendingRegistration(5, NORMALIZED_EMAIL)));
        when(mockEventDao.findById(EVENT_ID)).thenReturn(Optional.of(eventRequiringApproval(5)));
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventRequiringApproval(5)));
        when(mockRegistrationDao.countConfirmed(EVENT_ID)).thenReturn(1L, 2L);
        // Hay otro pedido pendiente: como todavia hay lugar, no debe pasar a la lista de espera.
        lenient().when(mockRegistrationDao.findPendingByEvent(EVENT_ID))
                .thenReturn(Collections.singletonList(pendingRegistration(6, "otro@mail.com")));

        when(mockRegistrationDao.updateStatus(5, RegistrationStatus.CONFIRMED)).thenReturn(true);
        // Act
        final ApprovalResult result = registrationService.approve(5, CREATOR_ID);

        // Assert
        assertEquals(ApprovalResult.Status.APPROVED, result.getStatus());
        // Quedan lugares (2 de 5): no se lleno, no se aviso.
        assertFalse(result.isNotificationSent());
    }

    // ---- reject() ----

    @Test
    public void testRejectMarksAPendingRegistrationOwnedByTheCreatorAsRejected() {
        // Arrange
        final Registration registration = new Registration(EVENT_ID, NORMALIZED_EMAIL, NAME, RegistrationStatus.PENDING);
        registration.setId(5);
        when(mockRegistrationDao.findById(5)).thenReturn(Optional.of(registration));
        when(mockEventDao.findById(EVENT_ID)).thenReturn(Optional.of(eventRequiringApproval(null)));
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventRequiringApproval(null)));

        when(mockRegistrationDao.updateStatus(5, RegistrationStatus.REJECTED)).thenReturn(true);
        // Act
        final boolean result = registrationService.reject(5, CREATOR_ID);

        // Assert
        assertTrue(result);
    }

    // Un pedido pendiente no ocupaba cupo: rechazarlo no libera ningun lugar, asi
    // que no hay nadie a quien promover desde la lista de espera.
    @Test
    public void testRejectDoesNotTouchTheWaitlistBecausePendingNeverHeldASpot() {
        // Arrange
        final Registration registration = new Registration(EVENT_ID, NORMALIZED_EMAIL, NAME, RegistrationStatus.PENDING);
        registration.setId(5);
        when(mockRegistrationDao.findById(5)).thenReturn(Optional.of(registration));
        when(mockEventDao.findById(EVENT_ID)).thenReturn(Optional.of(eventRequiringApproval(null)));
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventRequiringApproval(null)));

        when(mockRegistrationDao.updateStatus(5, RegistrationStatus.REJECTED)).thenReturn(true);
        // Act
        final boolean result = registrationService.reject(5, CREATOR_ID);

        // Assert
        assertTrue(result);
    }

    @Test
    public void testRejectReturnsFalseWhenTheEventBelongsToSomeoneElse() {
        // Arrange
        final Registration registration = new Registration(EVENT_ID, NORMALIZED_EMAIL, NAME, RegistrationStatus.PENDING);
        registration.setId(5);
        when(mockRegistrationDao.findById(5)).thenReturn(Optional.of(registration));
        when(mockEventDao.findById(EVENT_ID)).thenReturn(Optional.of(eventRequiringApproval(null)));

        // Act
        final boolean result = registrationService.reject(5, OTHER_ID);

        // Assert
        assertFalse(result);
    }

    @Test
    public void testRejectReturnsFalseWhenTheRegistrationIsNotPending() {
        // Arrange
        final Registration registration = new Registration(EVENT_ID, NORMALIZED_EMAIL, NAME, RegistrationStatus.WAITLISTED);
        registration.setId(5);
        when(mockRegistrationDao.findById(5)).thenReturn(Optional.of(registration));

        // Act
        final boolean result = registrationService.reject(5, CREATOR_ID);

        // Assert
        assertFalse(result);
    }

    // ---- revoke() ----

    private static Registration confirmedRegistration(final long id, final String email) {
        final Registration registration = new Registration(EVENT_ID, email, NAME, RegistrationStatus.CONFIRMED);
        registration.setId(id);
        return registration;
    }

    @Test
    public void testRevokeMarksAConfirmedRegistrationAsRejectedAndTellsThePerson() {
        // Arrange
        when(mockRegistrationDao.findById(7)).thenReturn(Optional.of(confirmedRegistration(7, NORMALIZED_EMAIL)));
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventWithCreator(10)));

        when(mockRegistrationDao.updateStatus(7, RegistrationStatus.REJECTED)).thenReturn(true);
        // Act
        final boolean result = registrationService.revoke(7, CREATOR_ID);

        // Assert
        assertTrue(result);
    }

    @Test
    public void testRevokeReturnsFalseWhenTheRegistrationIsNotConfirmed() {
        // Arrange
        when(mockRegistrationDao.findById(7)).thenReturn(Optional.of(pendingRegistration(7, NORMALIZED_EMAIL)));

        // Act
        final boolean result = registrationService.revoke(7, CREATOR_ID);

        // Assert
        assertFalse(result);
    }

    @Test
    public void testRevokeReturnsFalseWhenTheEventBelongsToSomeoneElse() {
        // Arrange
        when(mockRegistrationDao.findById(7)).thenReturn(Optional.of(confirmedRegistration(7, NORMALIZED_EMAIL)));
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventWithCreator(10)));

        // Act
        final boolean result = registrationService.revoke(7, OTHER_ID);

        // Assert
        assertFalse(result);
    }

    // ---- promoteFromWaitlist() ----

    @Test
    public void testPromoteConfirmsAsManyWaitlistedPeopleAsFreeSpotsInArrivalOrder() {
        // Arrange
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventWithCreator(5)));
        when(mockRegistrationDao.countConfirmed(EVENT_ID)).thenReturn(3L);
        when(mockInvitationDao.countOutstanding(EVENT_ID)).thenReturn(0L);
        final Registration first = new Registration(EVENT_ID, "a@mail.com", "A", RegistrationStatus.WAITLISTED);
        first.setId(1);
        final Registration second = new Registration(EVENT_ID, "b@mail.com", "B", RegistrationStatus.WAITLISTED);
        second.setId(2);
        when(mockRegistrationDao.findNextWaitlisted(EVENT_ID, 2)).thenReturn(Arrays.asList(first, second));

        when(mockRegistrationDao.updateStatus(1, RegistrationStatus.CONFIRMED)).thenReturn(true);
        when(mockRegistrationDao.updateStatus(2, RegistrationStatus.CONFIRMED)).thenReturn(true);
        // Act
        final int promoted = registrationService.promoteFromWaitlist(EVENT_ID);

        // Assert
        assertEquals(2, promoted);
    }

    // Las invitaciones a un evento privado reservan lugar: no se le da a la
    // lista de espera el lugar que esta prometido a alguien invitado.
    // En un evento que requiere confirmacion, quien sale de la lista de espera pasa a
    // PENDING (no a CONFIRMED): el organizador todavia lo tiene que aceptar.
    @Test
    public void testPromoteMovesWaitlistedToPendingWhenTheEventRequiresApproval() {
        // Arrange
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventRequiringApproval(5)));
        when(mockRegistrationDao.countConfirmed(EVENT_ID)).thenReturn(4L);
        when(mockRegistrationDao.countPending(EVENT_ID)).thenReturn(0L);
        final Registration waiting = new Registration(EVENT_ID, "espera@mail.com", "Beto", RegistrationStatus.WAITLISTED);
        waiting.setId(8);
        when(mockRegistrationDao.findNextWaitlisted(EVENT_ID, 1)).thenReturn(Collections.singletonList(waiting));

        when(mockRegistrationDao.updateStatus(8, RegistrationStatus.PENDING)).thenReturn(true);
        // Act
        final int promoted = registrationService.promoteFromWaitlist(EVENT_ID);

        // Assert
        assertEquals(1, promoted);
    }

    // Un lugar libre que ya tiene un pedido pendiente esperando respuesta no se le
    // "regala" tambien a la lista de espera.
    @Test
    public void testPromoteToPendingDiscountsRequestsAlreadyWaitingForAnAnswer() {
        // Arrange
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventRequiringApproval(5)));
        when(mockRegistrationDao.countConfirmed(EVENT_ID)).thenReturn(4L);
        when(mockRegistrationDao.countPending(EVENT_ID)).thenReturn(1L);
        // Hay alguien esperando: si el service ignorara el pendiente, lo promoveria.
        lenient().when(mockRegistrationDao.findNextWaitlisted(anyLong(), anyInt()))
                .thenReturn(Collections.singletonList(
                        new Registration(EVENT_ID, "espera@mail.com", "Beto", RegistrationStatus.WAITLISTED)));

        // Act
        final int promoted = registrationService.promoteFromWaitlist(EVENT_ID);

        // Assert
        assertEquals(0, promoted);
    }

    @Test
    public void testPromoteRespectsSpotsHeldByUnusedInvitations() {
        // Arrange
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventWithCreator(5)));
        when(mockRegistrationDao.countConfirmed(EVENT_ID)).thenReturn(3L);
        when(mockInvitationDao.countOutstanding(EVENT_ID)).thenReturn(2L);
        // Hay alguien esperando: si el service ignorara las invitaciones, lo promoveria.
        lenient().when(mockRegistrationDao.findNextWaitlisted(anyLong(), anyInt()))
                .thenReturn(Collections.singletonList(
                        new Registration(EVENT_ID, "espera@mail.com", "Beto", RegistrationStatus.WAITLISTED)));

        // Act
        final int promoted = registrationService.promoteFromWaitlist(EVENT_ID);

        // Assert
        assertEquals(0, promoted);
    }

    @Test
    public void testPromoteDoesNothingWhenTheEventIsFull() {
        // Arrange
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventWithCreator(2)));
        when(mockRegistrationDao.countConfirmed(EVENT_ID)).thenReturn(2L);

        // Act
        final int promoted = registrationService.promoteFromWaitlist(EVENT_ID);

        // Assert
        assertEquals(0, promoted);
    }

    @Test
    public void testPromoteDoesNothingForACancelledEvent() {
        // Arrange
        final Event cancelled = eventWithCreator(5);
        cancelled.setCancelledAt(new java.util.Date());
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(cancelled));

        // Act
        final int promoted = registrationService.promoteFromWaitlist(EVENT_ID);

        // Assert
        assertEquals(0, promoted);
    }

    // Si el organizador saca el limite de cupo, entra toda la lista de espera.
    @Test
    public void testPromoteConfirmsTheWholeWaitlistWhenTheEventBecomesUnlimited() {
        // Arrange
        when(mockEventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(eventWithCreator(null)));
        final Registration only = new Registration(EVENT_ID, "a@mail.com", "A", RegistrationStatus.WAITLISTED);
        only.setId(1);
        when(mockRegistrationDao.findNextWaitlisted(EVENT_ID, Integer.MAX_VALUE))
                .thenReturn(Collections.singletonList(only));

        when(mockRegistrationDao.updateStatus(1, RegistrationStatus.CONFIRMED)).thenReturn(true);
        // Act
        final int promoted = registrationService.promoteFromWaitlist(EVENT_ID);

        // Assert
        assertEquals(1, promoted);
    }

    // ---- occupiedSpots() ----

    @Test
    public void testOccupiedSpotsAddsTheConfirmedAndTheUnusedInvitations() {
        // Arrange
        when(mockRegistrationDao.countConfirmed(EVENT_ID)).thenReturn(7L);
        when(mockInvitationDao.countOutstanding(EVENT_ID)).thenReturn(2L);

        // Act
        final long result = registrationService.occupiedSpots(EVENT_ID);

        // Assert
        assertEquals(9L, result);
    }
}
