package ar.edu.itba.paw.services;

import ar.edu.itba.paw.dto.EventDTO;
import ar.edu.itba.paw.model.Event;
import ar.edu.itba.paw.model.EventCategoryInfo;
import ar.edu.itba.paw.model.EventSearchCriteria;
import ar.edu.itba.paw.model.User;
import ar.edu.itba.paw.model.exception.EventNotFoundException;
import ar.edu.itba.paw.model.exception.InvalidEventException;
import ar.edu.itba.paw.persistence.EventDao;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.dao.DataIntegrityViolationException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertSame;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.Mockito.when;

/**
 * Tests unitarios con Mockito: EventDao, UserService y RegistrationService son @Mock.
 * Los comandos del dao (update, cancel, removeByAdmin, setFeatured) devuelven boolean: el
 * test los stubea con argumentos especificos (si el service no los invoca, Mockito falla por
 * stub sin usar) y asierta sobre lo que devuelve el service. Los avisos (mail e inbox) son
 * "disparar y olvidar" (void) y no se testean aca: verificar que se llamaron seria testear la
 * implementacion de EventServiceImpl, no el contrato de EventService.
 */
@RunWith(MockitoJUnitRunner.class)
public class EventServiceImplTest {

    private static final long EVENT_ID = 1;
    private static final long CATEGORY_ID = 7;
    private static final String CREATOR_EMAIL = "creador@mail.com";
    private static final long CREATOR_ID = 42;

    private static final long OTHER_ID = 43;

    @Mock
    private EventDao eventDao;
    @Mock
    private UserService userService;
    @Mock
    private RegistrationService registrationService;
    @Mock
    private NotificationService notificationService;
    @Mock
    private InboxService inboxService;
    @Mock
    private ImageService imageService;

    private EventServiceImpl eventService;

    @Before
    public void setUp() {
        eventService = new EventServiceImpl(eventDao, userService, notificationService, registrationService,
                inboxService, imageService);
    }

    private static Event someEvent() {
        return eventWith(EVENT_ID, CATEGORY_ID, CREATOR_ID);
    }

    private static Event eventWith(final long id, final long categoryId, final long creatorId) {
        final Event event = new Event();
        event.setId(id);
        event.setCategories(Collections.singletonList(new EventCategoryInfo(categoryId)));
        event.setCreatorEmail(CREATOR_EMAIL);
        event.setCreatorId(creatorId);
        return event;
    }

    private static EventDTO someDto() {
        final EventDTO dto = new EventDTO();
        dto.setCategories(Collections.singletonList(new EventCategoryInfo(CATEGORY_ID)));
        dto.setCreatorEmail(CREATOR_EMAIL);
        dto.setCreatorId(CREATOR_ID);
        return dto;
    }

    private static List<Event> eventsWithIds(final int count) {
        final List<Event> events = new ArrayList<>();
        for (int i = 1; i <= count; i++) {
            events.add(eventWith(i, CATEGORY_ID, CREATOR_ID));
        }
        return events;
    }

    // El evento existe en el dao (con y sin lock, segun el metodo del service).
    private void existing(final Event event) {
        when(eventDao.findById(EVENT_ID)).thenReturn(Optional.of(event));
    }

    private void existingForUpdate(final Event event) {
        when(eventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.of(event));
    }

    private static Event cancelledEvent() {
        final Event event = someEvent();
        event.setCancelledAt(new Date());
        return event;
    }

    // ---- create() ----

    @Test
    public void testCreateReturnsTheEventThatTheDaoPersisted() {
        // Arrange
        final Event persisted = someEvent();
        when(eventDao.create(argThat(event -> Long.valueOf(CREATOR_ID).equals(event.getCreatorId()))))
                .thenReturn(persisted);

        // Act
        final Event result = eventService.create(someDto());

        // Assert
        assertSame(persisted, result);
    }

    @Test
    public void testCreateWithInvalidCategoryThrowsInvalidEventExceptionWithCategoryKey() {
        // Arrange
        when(eventDao.create(argThat(event -> true)))
                .thenThrow(new DataIntegrityViolationException("violates foreign key constraint event_category_category_id_fkey"));

        // Act
        final InvalidEventException thrown = assertThrows(InvalidEventException.class,
                () -> eventService.create(someDto()));

        // Assert
        assertEquals("event.publish.categoryNotFound", thrown.getMessageKey());
    }

    @Test
    public void testCreateWithAnyOtherConstraintViolationThrowsInvalidEventExceptionWithGenericKey() {
        // Arrange
        when(eventDao.create(argThat(event -> true)))
                .thenThrow(new DataIntegrityViolationException("value too long for column title"));

        // Act
        final InvalidEventException thrown = assertThrows(InvalidEventException.class,
                () -> eventService.create(someDto()));

        // Assert
        assertEquals("event.publish.invalidData", thrown.getMessageKey());
    }

    @Test
    public void testCreateStillReturnsTheEventWhenCreatorLookupFindsNothing() {
        // Arrange
        // El creador ya viene resuelto (creatorId) desde el controller: esto
        // solo puede pasar si esa fila desapareciera justo entre medio. No
        // tiene que romper la creacion del evento, solo el nombre del mail.
        final Event persisted = someEvent();
        when(eventDao.create(argThat(event -> true))).thenReturn(persisted);
        when(userService.findById(CREATOR_ID)).thenReturn(Optional.empty());

        // Act
        final Event result = eventService.create(someDto());

        // Assert
        assertSame(persisted, result);
    }

    // ---- findById / findByIds / findAll / findByCategory / findByCreatorId ----

    @Test
    public void testFindByIdReturnsThePresentEvent() {
        // Arrange
        existing(someEvent());

        // Act
        final Optional<Event> result = eventService.findById(EVENT_ID);

        // Assert
        assertTrue(result.isPresent());
        assertEquals(EVENT_ID, result.get().getId());
    }

    @Test
    public void testFindByIdReturnsEmptyWhenTheEventDoesNotExist() {
        // Arrange
        when(eventDao.findById(EVENT_ID)).thenReturn(Optional.empty());

        // Act
        final Optional<Event> result = eventService.findById(EVENT_ID);

        // Assert
        assertFalse(result.isPresent());
    }

    @Test
    public void testFindByIdsReturnsTheEventsTheDaoFinds() {
        // Arrange
        final List<Event> events = Arrays.asList(eventWith(1, CATEGORY_ID, CREATOR_ID), eventWith(3, CATEGORY_ID, CREATOR_ID));
        when(eventDao.findByIds(Arrays.asList(1L, 3L))).thenReturn(events);

        // Act
        final List<Event> result = eventService.findByIds(Arrays.asList(1L, 3L));

        // Assert
        assertEquals(events, result);
    }

    @Test
    public void testFindByCreatorIdReturnsTheEventsOfThatCreator() {
        // Arrange
        final List<Event> events = Collections.singletonList(eventWith(1, CATEGORY_ID, CREATOR_ID));
        when(eventDao.findByCreatorId(CREATOR_ID)).thenReturn(events);

        // Act
        final List<Event> result = eventService.findByCreatorId(CREATOR_ID);

        // Assert
        assertEquals(events, result);
    }

    // ---- search() ----

    private static EventSearchCriteria criteria(final int page, final int pageSize) {
        final EventSearchCriteria criteria = new EventSearchCriteria();
        criteria.setPage(page);
        criteria.setPageSize(pageSize);
        return criteria;
    }

    @Test
    public void testSearchReturnsTheRequestedPage() {
        // Arrange
        final EventSearchCriteria criteria = criteria(2, 10);
        final List<Event> page = eventsWithIds(10);
        when(eventDao.countSearch(criteria)).thenReturn(25L);
        when(eventDao.search(argThat(searched -> searched.getPage() == 2))).thenReturn(page);

        // Act
        final PageResult<Event> result = eventService.search(criteria);

        // Assert
        assertEquals(2, result.getPage());
        assertEquals(page, result.getContent());
    }

    @Test
    public void testSearchReturnsTheTotalNumberOfMatches() {
        // Arrange
        final EventSearchCriteria criteria = criteria(1, 10);
        when(eventDao.countSearch(criteria)).thenReturn(25L);
        when(eventDao.search(criteria)).thenReturn(eventsWithIds(10));

        // Act
        final PageResult<Event> result = eventService.search(criteria);

        // Assert
        assertEquals(25L, result.getTotalElements());
        assertEquals(3, result.getTotalPages());
    }

    @Test
    public void testSearchWhenThePageIsBeyondTheLastFallsBackToTheLastPage() {
        // Arrange
        final EventSearchCriteria criteria = criteria(99, 10);
        final List<Event> lastPage = eventsWithIds(5);
        when(eventDao.countSearch(criteria)).thenReturn(25L);
        when(eventDao.search(argThat(searched -> searched.getPage() == 3))).thenReturn(lastPage);

        // Act
        final PageResult<Event> result = eventService.search(criteria);

        // Assert
        assertEquals(3, result.getPage());
        assertEquals(lastPage, result.getContent());
    }

    @Test
    public void testSearchWhenThePageIsBelowOneFallsBackToTheFirstPage() {
        // Arrange
        final EventSearchCriteria criteria = criteria(0, 10);
        final List<Event> firstPage = eventsWithIds(10);
        when(eventDao.countSearch(criteria)).thenReturn(25L);
        when(eventDao.search(argThat(searched -> searched.getPage() == 1))).thenReturn(firstPage);

        // Act
        final PageResult<Event> result = eventService.search(criteria);

        // Assert
        assertEquals(1, result.getPage());
        assertEquals(firstPage, result.getContent());
    }

    @Test
    public void testSearchWithoutResultsReturnsTheFirstPageEmpty() {
        // Arrange
        final EventSearchCriteria criteria = criteria(5, 10);
        when(eventDao.countSearch(criteria)).thenReturn(0L);
        when(eventDao.search(argThat(searched -> searched.getPage() == 1))).thenReturn(Collections.emptyList());

        // Act
        final PageResult<Event> result = eventService.search(criteria);

        // Assert
        assertEquals(1, result.getPage());
        assertTrue(result.getContent().isEmpty());
    }

    // ---- update() ----

    // Caso feliz de update(): el evento es del que llama, sigue activo, y la capacidad nueva alcanza.
    private void updatable(final long occupied) {
        existingForUpdate(someEvent());
        when(registrationService.occupiedSpots(EVENT_ID)).thenReturn(occupied);
    }

    @Test
    public void testUpdateSucceedsAndReturnsUpdated() {
        // Arrange
        updatable(5);
        final EventDTO dto = someDto();
        dto.setMaxCapacity(20);

        // Act
        final EventUpdateResult result = eventService.update(EVENT_ID, dto, CREATOR_ID);

        // Assert
        assertEquals(EventUpdateResult.UPDATED, result);
    }

    @Test
    public void testUpdateStoresTheChangesUnderTheEventId() {
        // Arrange: el Event que arma toEvent() a partir del dto llega sin id,
        // el service se lo tiene que poner.
        updatable(0);
        final EventDTO dto = someDto();
        dto.setMaxCapacity(20);
        when(eventDao.update(argThat(updated -> updated.getId() == EVENT_ID))).thenReturn(true);

        // Act
        final EventUpdateResult result = eventService.update(EVENT_ID, dto, CREATOR_ID);

        // Assert
        assertEquals(EventUpdateResult.UPDATED, result);
    }

    @Test(expected = EventNotFoundException.class)
    public void testUpdateWhenCallerIsNotTheCreatorThrowsEventNotFoundException() {
        // Arrange
        existingForUpdate(someEvent());

        // Act
        eventService.update(EVENT_ID, someDto(), OTHER_ID);

        // Assert: la excepcion esperada en @Test(expected=...) ES el assert.
    }

    @Test(expected = EventNotFoundException.class)
    public void testUpdateWhenTheEventDoesNotExistThrowsEventNotFoundException() {
        // Arrange
        when(eventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.empty());

        // Act
        eventService.update(EVENT_ID, someDto(), CREATOR_ID);

        // Assert: la excepcion esperada en @Test(expected=...) ES el assert.
    }

    @Test
    public void testUpdateWhenTheEventIsCancelledReturnsCancelled() {
        // Arrange
        existingForUpdate(cancelledEvent());

        // Act
        final EventUpdateResult result = eventService.update(EVENT_ID, someDto(), CREATOR_ID);

        // Assert
        assertEquals(EventUpdateResult.CANCELLED, result);
    }

    @Test
    public void testUpdateWhenNewCapacityIsBelowOccupiedReturnsCapacityTooLow() {
        // Arrange
        updatable(5);
        final EventDTO dto = someDto();
        dto.setMaxCapacity(3);

        // Act
        final EventUpdateResult result = eventService.update(EVENT_ID, dto, CREATOR_ID);

        // Assert
        assertEquals(EventUpdateResult.CAPACITY_TOO_LOW, result);
    }

    @Test
    public void testUpdateWhenNewCapacityEqualsOccupiedSucceeds() {
        // Arrange
        updatable(5);
        final EventDTO dto = someDto();
        dto.setMaxCapacity(5);

        // Act
        final EventUpdateResult result = eventService.update(EVENT_ID, dto, CREATOR_ID);

        // Assert
        assertEquals(EventUpdateResult.UPDATED, result);
    }

    @Test
    public void testUpdateWhenNewCapacityIsNullSucceedsEvenIfSomeSpotsAreOccupied() {
        // Arrange
        // Sin cupo (ilimitado) no hay nada que comparar contra lo ocupado: tiene
        // que actualizar igual aunque haya lugares ocupados.
        existingForUpdate(someEvent());
        final EventDTO dto = someDto();
        dto.setMaxCapacity(null);

        // Act
        final EventUpdateResult result = eventService.update(EVENT_ID, dto, CREATOR_ID);

        // Assert
        assertEquals(EventUpdateResult.UPDATED, result);
    }

    // Si el organizador sube el cupo, los primeros de la lista de espera entran ya.
    @Test
    public void testUpdatePromotesTheWaitlistSoRaisedCapacityIsFilled() {
        // Arrange
        updatable(0);
        final EventDTO dto = someDto();
        dto.setMaxCapacity(20);
        when(registrationService.promoteFromWaitlist(EVENT_ID)).thenReturn(2);

        // Act
        final EventUpdateResult result = eventService.update(EVENT_ID, dto, CREATOR_ID);

        // Assert
        assertEquals(EventUpdateResult.UPDATED, result);
    }

    // ---- cancel() ----

    @Test
    public void testCancelSucceedsAndReturnsCancelled() {
        // Arrange
        existingForUpdate(someEvent());
        when(eventDao.cancel(EVENT_ID)).thenReturn(true);

        // Act
        final EventCancelResult result = eventService.cancel(EVENT_ID, CREATOR_ID);

        // Assert
        assertEquals(EventCancelResult.CANCELLED, result);
    }

    @Test(expected = EventNotFoundException.class)
    public void testCancelWhenCallerIsNotTheCreatorThrowsEventNotFoundException() {
        // Arrange
        existingForUpdate(someEvent());

        // Act
        eventService.cancel(EVENT_ID, OTHER_ID);

        // Assert: la excepcion esperada en @Test(expected=...) ES el assert.
    }

    @Test(expected = EventNotFoundException.class)
    public void testCancelWhenTheEventDoesNotExistThrowsEventNotFoundException() {
        // Arrange
        when(eventDao.findByIdForUpdate(EVENT_ID)).thenReturn(Optional.empty());

        // Act
        eventService.cancel(EVENT_ID, CREATOR_ID);

        // Assert: la excepcion esperada en @Test(expected=...) ES el assert.
    }

    @Test
    public void testCancelWhenAlreadyCancelledReturnsAlreadyCancelled() {
        // Arrange
        existingForUpdate(cancelledEvent());

        // Act
        final EventCancelResult result = eventService.cancel(EVENT_ID, CREATOR_ID);

        // Assert
        assertEquals(EventCancelResult.ALREADY_CANCELLED, result);
    }

    // ---- removeByAdmin() (moderacion) ----

    @Test
    public void testRemoveByAdminSucceedsRegardlessOfWhoCreatedTheEvent() {
        // Arrange
        // removeByAdmin() y cancel() devuelven el mismo CANCELLED: lo que los distingue es el
        // comando del dao que ejecutan (removeByAdmin guarda la marca "retirado por un admin" y el motivo).
        existing(someEvent());
        when(eventDao.removeByAdmin(EVENT_ID, "Contenido inapropiado")).thenReturn(true);

        // Act
        final EventCancelResult result = eventService.removeByAdmin(EVENT_ID, "Contenido inapropiado");

        // Assert
        assertEquals(EventCancelResult.CANCELLED, result);
    }

    @Test
    public void testRemoveByAdminWhenTheEventDoesNotExistReturnsNotFound() {
        // Arrange
        when(eventDao.findById(EVENT_ID)).thenReturn(Optional.empty());

        // Act
        final EventCancelResult result = eventService.removeByAdmin(EVENT_ID, "motivo");

        // Assert
        assertEquals(EventCancelResult.NOT_FOUND, result);
    }

    @Test
    public void testRemoveByAdminWhenAlreadyCancelledReturnsAlreadyCancelled() {
        // Arrange
        existing(cancelledEvent());

        // Act
        final EventCancelResult result = eventService.removeByAdmin(EVENT_ID, "motivo");

        // Assert
        assertEquals(EventCancelResult.ALREADY_CANCELLED, result);
    }

    // ---- findFeatured() / setFeatured() (banner de /eventos) ----

    @Test
    public void testFindFeaturedReturnsTheFeaturedEventsTheDaoFinds() {
        // Arrange
        final List<Event> featured = Arrays.asList(eventWith(2, CATEGORY_ID, CREATOR_ID), eventWith(3, CATEGORY_ID, CREATOR_ID));
        when(eventDao.findFeatured(2)).thenReturn(featured);

        // Act
        final List<Event> result = eventService.findFeatured(2);

        // Assert
        assertEquals(featured, result);
    }

    @Test
    public void testSetFeaturedTrueReturnsTrueWhenTheEventWasMarked() {
        // Arrange
        when(eventDao.setFeatured(EVENT_ID, true)).thenReturn(true);

        // Act
        final boolean result = eventService.setFeatured(EVENT_ID, true);

        // Assert
        assertTrue(result);
    }

    @Test
    public void testSetFeaturedFalseReturnsTrueWhenTheEventWasUnmarked() {
        // Arrange
        when(eventDao.setFeatured(EVENT_ID, false)).thenReturn(true);

        // Act
        final boolean result = eventService.setFeatured(EVENT_ID, false);

        // Assert
        assertTrue(result);
    }

    @Test
    public void testSetFeaturedReturnsFalseWhenTheEventDoesNotExist() {
        // Arrange
        when(eventDao.setFeatured(EVENT_ID, true)).thenReturn(false);

        // Act
        final boolean result = eventService.setFeatured(EVENT_ID, true);

        // Assert
        assertFalse(result);
    }
}
