package ar.edu.itba.paw.services;

import ar.edu.itba.paw.model.InboxMessage;
import ar.edu.itba.paw.model.InboxMessageType;
import ar.edu.itba.paw.model.User;
import ar.edu.itba.paw.persistence.InboxMessageDao;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertSame;
import static org.mockito.ArgumentMatchers.argThat;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.when;

/**
 * Tests unitarios con Mockito: InboxMessageDao y UserService son @Mock. Los stubs con
 * argumentos especificos hacen de expectativa (si el service arma mal el mensaje, no
 * matchean y el test falla) y se asierta sobre lo que devuelve el service.
 */
@RunWith(MockitoJUnitRunner.class)
public class InboxServiceImplTest {

    private static final long USER_ID = 55;

    @Mock
    private InboxMessageDao inboxDao;
    @Mock
    private UserService userService;

    private InboxServiceImpl inboxService;

    @Before
    public void setUp() {
        inboxService = new InboxServiceImpl(inboxDao, userService);
    }

    private static InboxMessage anyMessage() {
        return new InboxMessage("ana@mail.com", InboxMessageType.NEW_PENDING, 7L, "Juan", null);
    }

    // ---- add() ----

    @Test
    public void testAddNormalizesTheEmail() {
        // Arrange
        final InboxMessage saved = anyMessage();
        when(userService.findByEmail("ana@mail.com")).thenReturn(Optional.empty());
        when(inboxDao.create(argThat(message -> "ana@mail.com".equals(message.getRecipientEmail()))))
                .thenReturn(saved);

        // Act
        final InboxMessage result = inboxService.add("  Ana@Mail.com ", InboxMessageType.NEW_PENDING, 7L, "Juan", null);

        // Assert
        assertSame(saved, result);
    }

    @Test
    public void testAddKeepsTheTypeEventActorAndBody() {
        // Arrange
        final InboxMessage saved = anyMessage();
        when(userService.findByEmail("ana@mail.com")).thenReturn(Optional.empty());
        when(inboxDao.create(argThat(message -> message.getType() == InboxMessageType.NEW_PENDING
                && Long.valueOf(7).equals(message.getEventId())
                && "Juan".equals(message.getActorName())
                && "texto".equals(message.getBody())))).thenReturn(saved);

        // Act
        final InboxMessage result = inboxService.add("ana@mail.com", InboxMessageType.NEW_PENDING, 7L, "Juan", "texto");

        // Assert
        assertSame(saved, result);
    }

    @Test
    public void testAddLeavesTheUserIdEmptyWhenTheRecipientHasNoAccountYet() {
        // Arrange
        final InboxMessage saved = anyMessage();
        when(userService.findByEmail("ana@mail.com")).thenReturn(Optional.empty());
        when(inboxDao.create(argThat(message -> message.getUserId() == null))).thenReturn(saved);

        // Act
        final InboxMessage result = inboxService.add("ana@mail.com", InboxMessageType.NEW_PENDING, 7L, "Juan", null);

        // Assert
        assertSame(saved, result);
    }

    @Test
    public void testAddLinksTheRecipientsUserIdWhenTheyAlreadyHaveAnAccount() {
        // Arrange
        final User recipient = new User("ana@mail.com", "Ana");
        recipient.setId(USER_ID);
        final InboxMessage saved = anyMessage();
        when(userService.findByEmail("ana@mail.com")).thenReturn(Optional.of(recipient));
        when(inboxDao.create(argThat(message -> Long.valueOf(USER_ID).equals(message.getUserId()))))
                .thenReturn(saved);

        // Act
        final InboxMessage result = inboxService.add("  Ana@Mail.com ", InboxMessageType.NEW_PENDING, 7L, "Juan", null);

        // Assert
        assertSame(saved, result);
    }

    // ---- findPage() ----

    @Test
    public void testFindPageTreatsAnInvalidPageAsTheFirst() {
        // Arrange
        final List<InboxMessage> messages = Arrays.asList(anyMessage(), anyMessage(), anyMessage());
        when(inboxDao.findByRecipientUserId(USER_ID, 1, InboxServiceImpl.PAGE_SIZE)).thenReturn(messages);
        when(inboxDao.countByUserId(USER_ID)).thenReturn(3L);

        // Act
        final PageResult<InboxMessage> result = inboxService.findPage(USER_ID, -3);

        // Assert
        assertEquals(1, result.getPage());
        assertEquals(messages, result.getContent());
    }

    @Test
    public void testFindPageCalculatesTotalPages() {
        // Arrange
        when(inboxDao.findByRecipientUserId(USER_ID, 2, InboxServiceImpl.PAGE_SIZE))
                .thenReturn(Collections.emptyList());
        when(inboxDao.countByUserId(USER_ID)).thenReturn(45L);

        // Act
        final PageResult<InboxMessage> result = inboxService.findPage(USER_ID, 2);

        // Assert
        assertEquals(3, result.getTotalPages());
    }

    @Test
    public void testFindPageReturnsTheRequestedPageAndTheTotalCount() {
        // Arrange
        final List<InboxMessage> lastPage = Arrays.asList(anyMessage(), anyMessage());
        when(inboxDao.findByRecipientUserId(USER_ID, 3, InboxServiceImpl.PAGE_SIZE)).thenReturn(lastPage);
        when(inboxDao.countByUserId(USER_ID)).thenReturn(42L);

        // Act
        final PageResult<InboxMessage> result = inboxService.findPage(USER_ID, 3);

        // Assert
        assertEquals(lastPage, result.getContent());
        assertEquals(42L, result.getTotalElements());
        assertEquals(3, result.getPage());
    }

    // ---- markAllRead() ----

    @Test
    public void testMarkAllReadReturnsHowManyMessagesWereMarked() {
        // Arrange
        when(inboxDao.markAllReadByUserId(eq(USER_ID), argThat(date -> date != null))).thenReturn(2);

        // Act
        final int result = inboxService.markAllRead(USER_ID);

        // Assert
        assertEquals(2, result);
    }

    @Test
    public void testMarkAllReadStampsTheReadMomentWithNow() {
        // Arrange
        final long before = new Date().getTime();
        when(inboxDao.markAllReadByUserId(eq(USER_ID),
                argThat(date -> Math.abs(date.getTime() - before) < 5000))).thenReturn(1);

        // Act
        final int result = inboxService.markAllRead(USER_ID);

        // Assert
        assertEquals(1, result);
    }

    // ---- countUnread() ----

    @Test
    public void testCountUnreadReturnsTheUnreadCountOfThatUser() {
        // Arrange
        when(inboxDao.countUnreadByUserId(USER_ID)).thenReturn(2L);

        // Act
        final long result = inboxService.countUnread(USER_ID);

        // Assert
        assertEquals(2, result);
    }
}
