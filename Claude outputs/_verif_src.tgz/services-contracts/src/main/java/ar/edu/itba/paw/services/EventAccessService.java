// Contrato de servicio para EventAccessService. Implementacion: EventAccessServiceImpl (modulo services).
package ar.edu.itba.paw.services;

import ar.edu.itba.paw.model.Event;
import ar.edu.itba.paw.model.Registration;
import ar.edu.itba.paw.model.User;
import ar.edu.itba.paw.model.exception.EventCancelledException;
import ar.edu.itba.paw.model.exception.EventNotFoundException;

import java.util.Optional;

public interface EventAccessService {

    /**
     * Un evento publico lo puede ver cualquiera, como siempre. Uno privado solo
     * su creador, alguien que ya tenga una fila de inscripcion (en cualquier
     * estado, incluido rechazado: si te rechazaron es porque en algun momento
     * tuviste acceso, no tiene sentido que ahora te vuelvas a topar con un 404),
     * o alguien cuya cuenta (la de su sesion) fue invitada. El link del mail solo
     * dice que evento es: quien sos lo dice tu sesion.
     * Lo comparten EventController, EventRegistrationController, EventQuestionController,
     * ProfileController e ImageController: por eso vive en un service aparte y no
     * como metodo privado de un solo controller.
     */
    boolean canView(Event event, User user, Optional<Registration> myRegistration);

    /**
     * Como {@link #canView(Event, User, Optional)}, pero tira EventNotFoundException en vez de
     * devolver false. Para quien ya tiene el Event y el Optional&lt;Registration&gt; en mano (ver
     * EventController.detail(), que los necesita de nuevo mas abajo para la tarjeta de RSVP) y
     * no quiere armar el if/throw el mismo -- esa decision le corresponde al service, no al
     * controller.
     *
     * @throws EventNotFoundException si no puede verlo. Mismo error que si no existiera.
     */
    void requireViewable(Event event, User user, Optional<Registration> myRegistration);

    /**
     * Igual que {@link #canView(Event, User, Optional)}, pero busca la inscripcion propia solo si hace
     * falta (un evento publico lo ve cualquiera, ni se consulta). {@code user} puede ser null (sin sesion).
     */
    boolean canView(Event event, User user);

    /**
     * El evento, si existe y {@code user} puede verlo.
     *
     * @throws EventNotFoundException si no existe o no puede verlo. Es el mismo error en los dos casos:
     *                                no se le confirma a nadie que un evento privado existe.
     */
    Event getViewableEvent(long eventId, User user);

    /**
     * El evento, si existe y {@code user} es su creador.
     *
     * @throws EventNotFoundException si no existe o {@code user} no es el creador (mismo error en los dos casos).
     */
    Event getOwnedEvent(long eventId, User user);

    /**
     * Como {@link #getOwnedEvent(long, User)}, pero ademas el evento tiene que ser privado: solo
     * a esos se invita (uno publico ya tiene un link que se puede compartir). Lo comparten el GET
     * y el POST de invitar de ProfileController.
     *
     * @throws EventNotFoundException si no existe, {@code user} no es el creador, o el evento no es
     *                                privado (mismo error en los tres casos).
     */
    Event getOwnedPrivateEvent(long eventId, User user);

    /**
     * Como {@link #getOwnedEvent(long, User)}, pero ademas tira EventCancelledException si el
     * evento ya esta cancelado: uno cancelado no se edita. Lo comparten el GET y el POST de
     * EventController para editar (editarForm()/editar()): misma regla, mismo lugar.
     *
     * @throws EventNotFoundException si no existe o {@code user} no es el creador.
     * @throws EventCancelledException si existe, es suyo, pero esta cancelado.
     */
    Event getEditableEvent(long eventId, User user);
}
