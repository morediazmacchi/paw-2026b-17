// Contrato de servicio para EventAccessService. Implementacion: EventAccessServiceImpl (modulo services).
package ar.edu.itba.paw.services;

import ar.edu.itba.paw.model.Event;
import ar.edu.itba.paw.model.Registration;
import ar.edu.itba.paw.model.User;
import ar.edu.itba.paw.model.exception.EventNotFoundException;

import java.util.Optional;

public interface EventAccessService {

    /**
     * Un evento publico lo puede ver cualquiera, como siempre. Uno privado solo
     * su creador, alguien que ya tenga una fila de inscripcion (en cualquier
     * estado, incluido rechazado: si te rechazaron es porque en algun momento
     * tuviste acceso, no tiene sentido que ahora te vuelvas a topar con un 404),
     * o alguien cuya cuenta (la de su sesion) fue invitada. El link del mail solo
     * dice que evento es: quien sos lo dice tu sesion.
     * Lo comparten EventController, EventRegistrationController, EventQuestionController,
     * ProfileController e ImageController: por eso vive en un service aparte y no
     * como metodo privado de un solo controller.
     */
    boolean canView(Event event, User user, Optional<Registration> myRegistration);

    /**
     * Igual que {@link #canView(Event, User, Optional)}, pero busca la inscripcion propia solo si hace
     * falta (un evento publico lo ve cualquiera, ni se consulta). {@code user} puede ser null (sin sesion).
     */
    boolean canView(Event event, User user);

    /**
     * El evento, si existe y {@code user} puede verlo.
     *
     * @throws EventNotFoundException si no existe o no puede verlo. Es el mismo error en los dos casos:
     *                                no se le confirma a nadie que un evento privado existe.
     */
    Event getViewableEvent(long eventId, User user);

    /**
     * El evento, si existe y {@code user} es su creador.
     *
     * @throws EventNotFoundException si no existe o {@code user} no es el creador (mismo error en los dos casos).
     */
    Event getOwnedEvent(long eventId, User user);
}
