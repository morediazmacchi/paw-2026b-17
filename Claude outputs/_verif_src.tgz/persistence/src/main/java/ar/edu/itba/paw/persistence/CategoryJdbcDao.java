// Implementa el contrato CategoryDao (modulo persistence-contracts).
package ar.edu.itba.paw.persistence;

import ar.edu.itba.paw.model.Category;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.util.List;

@Repository
public class CategoryJdbcDao implements CategoryDao {

    private static final RowMapper<Category> ROW_MAPPER = (rs, rowNum) -> {
        final Category category = new Category();
        category.setId(rs.getLong("id"));
        category.setName(rs.getString("name"));
        return category;
    };

    private final JdbcTemplate jdbcTemplate;

    @Autowired
    public CategoryJdbcDao(final DataSource ds) {
        this.jdbcTemplate = new JdbcTemplate(ds);
    }

    @Override
    public List<Category> findAll() {
        return jdbcTemplate.query("SELECT * FROM category ORDER BY name", ROW_MAPPER);
    }
}
