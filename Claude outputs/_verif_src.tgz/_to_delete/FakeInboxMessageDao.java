package ar.edu.itba.paw.services;

import ar.edu.itba.paw.model.InboxMessage;
import ar.edu.itba.paw.persistence.InboxMessageDao;
import java.util.*;

/**
 * InboxMessageDao "de mentira" en memoria para los tests de services.
 * Guarda los mensajes en una lista.
 * Fake escrito a mano (Sotuyo, clase de testing): se prueba por el ESTADO que queda,
 * sin Mockito. Lo que el service no usa tira UnsupportedOperationException.
 */
public class FakeInboxMessageDao implements InboxMessageDao {

    private final List<InboxMessage> messages = new ArrayList<>();
    private final List<Object[]> linkRequests = new ArrayList<>();
    private long nextId = 1;

    @Override
    public InboxMessage create(final InboxMessage message) {
        message.setId(nextId++);
        messages.add(message);
        return message;
    }

    @Override
    public List<InboxMessage> findByRecipient(final String email, final int page, final int pageSize) {
        throw new UnsupportedOperationException("findByRecipient: este fake no lo implementa");
    }

    @Override
    public long countByRecipient(final String email) {
        throw new UnsupportedOperationException("countByRecipient: este fake no lo implementa");
    }

    @Override
    public long countUnread(final String email) {
        throw new UnsupportedOperationException("countUnread: este fake no lo implementa");
    }

    @Override
    public void markAllRead(final String email, final Date when) {
        throw new UnsupportedOperationException("markAllRead: este fake no lo implementa");
    }

    @Override
    public List<InboxMessage> findByRecipientUserId(final long userId, final int page, final int pageSize) {
        final List<InboxMessage> ofUser = new ArrayList<>();
        for (final InboxMessage message : messages) {
            if (message.getUserId() != null && message.getUserId() == userId) {
                ofUser.add(message);
            }
        }
        // Mas nuevo primero (el id desempata), como el ORDER BY real.
        ofUser.sort((a, b) -> Long.compare(b.getId(), a.getId()));
        final int from = Math.min((page - 1) * pageSize, ofUser.size());
        final int to = Math.min(from + pageSize, ofUser.size());
        return new ArrayList<>(ofUser.subList(from, to));
    }

    @Override
    public long countByUserId(final long userId) {
        long count = 0;
        for (final InboxMessage message : messages) {
            if (message.getUserId() != null && message.getUserId() == userId) {
                count++;
            }
        }
        return count;
    }

    @Override
    public long countUnreadByUserId(final long userId) {
        long count = 0;
        for (final InboxMessage message : messages) {
            if (message.getUserId() != null && message.getUserId() == userId && message.isUnread()) {
                count++;
            }
        }
        return count;
    }

    @Override
    public void markAllReadByUserId(final long userId, final Date when) {
        for (final InboxMessage message : messages) {
            if (message.getUserId() != null && message.getUserId() == userId && message.isUnread()) {
                message.setReadAt(when);
            }
        }
    }

    @Override
    public void linkUserId(final String email, final long userId) {
        for (final InboxMessage message : messages) {
            if (message.getUserId() == null && message.getRecipientEmail().equals(email)) {
                message.setUserId(userId);
            }
        }
        linkRequests.add(new Object[] {email, userId});
    }

    /** Arma el estado inicial: un mensaje que "ya estaba en la base". */
    public FakeInboxMessageDao with(final InboxMessage message) {
        message.setId(nextId++);
        messages.add(message);
        return this;
    }

    /** Los mensajes que quedaron guardados, en orden. */
    public List<InboxMessage> all() {
        return messages;
    }

    /** Pedidos de linkUserId(email, userId) recibidos, en orden (cada uno: {email, userId}). */
    public List<Object[]> linkRequests() {
        return linkRequests;
    }

}
