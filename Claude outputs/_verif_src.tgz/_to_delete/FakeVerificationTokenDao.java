package ar.edu.itba.paw.services;

import ar.edu.itba.paw.model.TokenPurpose;
import ar.edu.itba.paw.model.VerificationToken;
import ar.edu.itba.paw.persistence.VerificationTokenDao;
import java.util.*;

/**
 * VerificationTokenDao "de mentira" en memoria para los tests de services.
 * Guarda los tokens en una lista.
 * Fake escrito a mano (Sotuyo, clase de testing): se prueba por el ESTADO que queda,
 * sin Mockito. Lo que el service no usa tira UnsupportedOperationException.
 */
public class FakeVerificationTokenDao implements VerificationTokenDao {

    private final List<VerificationToken> tokens = new ArrayList<>();

    @Override
    public void create(final VerificationToken token) {
        tokens.add(token);
    }

    @Override
    public Optional<VerificationToken> findByToken(final String token) {
        for (final VerificationToken stored : tokens) {
            if (stored.getToken().equals(token)) {
                return Optional.of(stored);
            }
        }
        return Optional.empty();
    }

    @Override
    public void delete(final String token) {
        tokens.removeIf(stored -> stored.getToken().equals(token));
    }

    @Override
    public void deleteByUserAndPurpose(final long userId, final TokenPurpose purpose) {
        tokens.removeIf(stored -> stored.getUserId() == userId && stored.getPurpose() == purpose);
    }

    /** Arma el estado inicial: un token que "ya estaba en la base". */
    public FakeVerificationTokenDao with(final VerificationToken token) {
        tokens.add(token);
        return this;
    }

    /** Los tokens que quedaron guardados, en orden. */
    public List<VerificationToken> all() {
        return tokens;
    }

    /** Los tokens que quedaron para ese usuario y ese motivo. */
    public List<VerificationToken> of(final long userId, final TokenPurpose purpose) {
        final List<VerificationToken> result = new ArrayList<>();
        for (final VerificationToken stored : tokens) {
            if (stored.getUserId() == userId && stored.getPurpose() == purpose) {
                result.add(stored);
            }
        }
        return result;
    }

}
