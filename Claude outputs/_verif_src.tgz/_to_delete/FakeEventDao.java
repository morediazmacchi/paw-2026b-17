package ar.edu.itba.paw.services;

import ar.edu.itba.paw.model.Event;
import ar.edu.itba.paw.model.EventCategoryInfo;
import ar.edu.itba.paw.model.EventSearchCriteria;
import ar.edu.itba.paw.persistence.EventDao;
import java.util.*;

/**
 * EventDao "de mentira" en memoria para los tests de services.
 * Guarda los eventos en un mapa; cancel/removeByAdmin/setFeatured/markReminderSent cambian el estado igual que el UPDATE real; search() pagina como el real (solo sin filtros).
 * Fake escrito a mano (Sotuyo, clase de testing): se prueba por el ESTADO que queda,
 * sin Mockito. Lo que el service no usa tira UnsupportedOperationException.
 */
public class FakeEventDao implements EventDao {

    private final Map<Long, Event> events = new LinkedHashMap<>();
    private final Set<Long> remindersSent = new HashSet<>();
    private long nextId = 1;
    private RuntimeException createFailure;

    @Override
    public Event create(final Event event) {
        if (createFailure != null) {
            throw createFailure;
        }
        event.setId(nextId++);
        events.put(event.getId(), event);
        return event;
    }

    @Override
    public void update(final Event event) {
        events.put(event.getId(), event);
    }

    @Override
    public void cancel(final long id) {
        final Event event = events.get(id);
        if (event != null) {
            event.setCancelledAt(new Date());
        }
    }

    @Override
    public void removeByAdmin(final long id, final String reason) {
        final Event event = events.get(id);
        if (event != null) {
            event.setCancelledAt(new Date());
            event.setRemovedByAdmin(true);
            event.setRemovedReason(reason);
        }
    }

    @Override
    public Optional<Event> findById(final long id) {
        return Optional.ofNullable(events.get(id));
    }

    @Override
    public Optional<Event> findByIdForUpdate(final long id) {
        return Optional.ofNullable(events.get(id));
    }

    @Override
    public List<Event> findByIds(final List<Long> ids) {
        final List<Event> result = new ArrayList<>();
        for (final Long id : ids) {
            if (events.containsKey(id)) {
                result.add(events.get(id));
            }
        }
        return result;
    }

    @Override
    public List<Event> findAll() {
        return new ArrayList<>(events.values());
    }

    @Override
    public List<Event> findByCategory(final long categoryId) {
        final List<Event> result = new ArrayList<>();
        for (final Event event : events.values()) {
            for (final EventCategoryInfo category : event.getCategories()) {
                if (category.getCategoryId() == categoryId) {
                    result.add(event);
                    break;
                }
            }
        }
        return result;
    }

    @Override
    public List<Event> findByCreatorId(final long creatorId) {
        final List<Event> result = new ArrayList<>();
        for (final Event event : events.values()) {
            if (Long.valueOf(creatorId).equals(event.getCreatorId())) {
                result.add(event);
            }
        }
        return result;
    }

    @Override
    public List<Event> search(final EventSearchCriteria criteria) {
        final List<Event> all = new ArrayList<>(events.values());
        final int from = Math.min((criteria.getPage() - 1) * criteria.getPageSize(), all.size());
        final int to = Math.min(from + criteria.getPageSize(), all.size());
        return new ArrayList<>(all.subList(from, to));
    }

    @Override
    public long countSearch(final EventSearchCriteria criteria) {
        return events.size();
    }

    @Override
    public List<Long> findIdsNeedingReminder(final java.util.Date from, final java.util.Date until) {
        final List<Long> result = new ArrayList<>();
        for (final Event event : events.values()) {
            if (event.getEventDate().after(from) && !event.getEventDate().after(until)
                    && !event.isCancelled() && !remindersSent.contains(event.getId())) {
                result.add(event.getId());
            }
        }
        return result;
    }

    @Override
    public boolean markReminderSent(final long id, final java.util.Date when) {
        return events.containsKey(id) && remindersSent.add(id);
    }

    @Override
    public List<Event> findFeatured(final int limit) {
        final List<Event> featured = new ArrayList<>();
        for (final Event event : events.values()) {
            if (event.isFeatured() && !event.isCancelled()) {
                featured.add(event);
            }
        }
        featured.sort((a, b) -> b.getFeaturedAt().compareTo(a.getFeaturedAt()));
        return new ArrayList<>(featured.subList(0, Math.min(limit, featured.size())));
    }

    @Override
    public void setFeatured(final long eventId, final boolean featured) {
        final Event event = events.get(eventId);
        if (event != null) {
            event.setFeatured(featured);
            event.setFeaturedAt(featured ? new Date() : null);
        }
    }

    /** Deja un evento ya guardado (con su id), como si estuviera en la base. */
    public FakeEventDao with(final Event event) {
        events.put(event.getId(), event);
        return this;
    }

    /** Hace que create() falle como falla la base cuando la categoria no existe (FK). */
    public FakeEventDao failingCreateWith(final RuntimeException failure) {
        this.createFailure = failure;
        return this;
    }

    /** El evento guardado con ese id, o null si no hay. */
    public Event stored(final long id) {
        return events.get(id);
    }

    public int size() {
        return events.size();
    }

    /** true si markReminderSent() ya reclamo el recordatorio de ese evento. */
    public boolean reminderSent(final long id) {
        return remindersSent.contains(id);
    }

}
