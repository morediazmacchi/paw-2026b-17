package ar.edu.itba.paw.services;

import ar.edu.itba.paw.dto.EventDTO;
import ar.edu.itba.paw.model.Event;
import ar.edu.itba.paw.model.EventSearchCriteria;
import ar.edu.itba.paw.services.EventService;
import java.util.*;

/**
 * EventService "de mentira" en memoria para los tests de services.
 * Solo implementa findById (un unico evento) y removeByAdmin (anota cada pedido).
 * Fake escrito a mano (Sotuyo, clase de testing): se prueba por el ESTADO que queda,
 * sin Mockito. Lo que el service no usa tira UnsupportedOperationException.
 */
public class FakeEventService implements EventService {

    private Event event;
    private final List<Object[]> removedByAdmin = new ArrayList<>();

    @Override
    public Event create(final EventDTO dto) {
        throw new UnsupportedOperationException("create: este fake no lo implementa");
    }

    @Override
    public Optional<Event> findById(final long id) {
        return event != null && event.getId() == id ? Optional.of(event) : Optional.empty();
    }

    @Override
    public List<Event> findByIds(final List<Long> ids) {
        throw new UnsupportedOperationException("findByIds: este fake no lo implementa");
    }

    @Override
    public List<Event> findAll() {
        throw new UnsupportedOperationException("findAll: este fake no lo implementa");
    }

    @Override
    public List<Event> findByCategory(final long categoryId) {
        throw new UnsupportedOperationException("findByCategory: este fake no lo implementa");
    }

    @Override
    public PageResult<Event> search(final EventSearchCriteria criteria) {
        throw new UnsupportedOperationException("search: este fake no lo implementa");
    }

    @Override
    public List<Event> findByCreatorId(final long creatorId) {
        throw new UnsupportedOperationException("findByCreatorId: este fake no lo implementa");
    }

    @Override
    public EventUpdateResult update(final long eventId, final Event changes, final long callerId) {
        throw new UnsupportedOperationException("update: este fake no lo implementa");
    }

    @Override
    public EventCancelResult cancel(final long eventId, final long callerId) {
        throw new UnsupportedOperationException("cancel: este fake no lo implementa");
    }

    @Override
    public EventCancelResult removeByAdmin(final long eventId, final String reason) {
        removedByAdmin.add(new Object[] {eventId, reason});
        return EventCancelResult.CANCELLED;
    }

    @Override
    public List<Event> findFeatured(final int limit) {
        throw new UnsupportedOperationException("findFeatured: este fake no lo implementa");
    }

    @Override
    public void setFeatured(final long eventId, final boolean featured) {
        throw new UnsupportedOperationException("setFeatured: este fake no lo implementa");
    }

    /** El unico evento que "existe" para findById(). */
    public FakeEventService with(final Event event) {
        this.event = event;
        return this;
    }

    /** Pedidos de removeByAdmin(eventId, reason) recibidos, en orden (cada uno: {eventId, reason}). */
    public List<Object[]> removedByAdmin() {
        return removedByAdmin;
    }

}
