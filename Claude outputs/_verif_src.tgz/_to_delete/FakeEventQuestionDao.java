package ar.edu.itba.paw.services;

import ar.edu.itba.paw.model.EventQuestion;
import ar.edu.itba.paw.persistence.EventQuestionDao;
import java.util.*;

/**
 * EventQuestionDao "de mentira" en memoria para los tests de services.
 * Guarda las preguntas en un mapa; answer() solo responde una pregunta sin responder, igual que el UPDATE real.
 * Fake escrito a mano (Sotuyo, clase de testing): se prueba por el ESTADO que queda,
 * sin Mockito. Lo que el service no usa tira UnsupportedOperationException.
 */
public class FakeEventQuestionDao implements EventQuestionDao {

    private final Map<Long, EventQuestion> questions = new LinkedHashMap<>();
    private long nextId = 1;

    @Override
    public EventQuestion create(final EventQuestion question) {
        question.setId(nextId++);
        question.setCreatedAt(new Date());
        questions.put(question.getId(), question);
        return question;
    }

    @Override
    public Optional<EventQuestion> findById(final long id) {
        return Optional.ofNullable(questions.get(id));
    }

    @Override
    public List<EventQuestion> findByEvent(final long eventId, final int page, final int pageSize) {
        final List<EventQuestion> ofEvent = new ArrayList<>();
        for (final EventQuestion question : questions.values()) {
            if (question.getEventId() == eventId) {
                ofEvent.add(question);
            }
        }
        // Mas nueva primero (el id desempata), como el ORDER BY real.
        ofEvent.sort((a, b) -> Long.compare(b.getId(), a.getId()));
        final int from = Math.min((page - 1) * pageSize, ofEvent.size());
        final int to = Math.min(from + pageSize, ofEvent.size());
        return new ArrayList<>(ofEvent.subList(from, to));
    }

    @Override
    public long countByEvent(final long eventId) {
        long count = 0;
        for (final EventQuestion question : questions.values()) {
            if (question.getEventId() == eventId) {
                count++;
            }
        }
        return count;
    }

    @Override
    public boolean answer(final long id, final String answer, final Date when) {
        final EventQuestion question = questions.get(id);
        if (question == null || question.isAnswered()) {
            return false;
        }
        question.setAnswer(answer);
        question.setAnsweredAt(when);
        return true;
    }

    @Override
    public void delete(final long id) {
        questions.remove(id);
    }

    /** Deja una pregunta ya guardada (con su id), como si estuviera en la base. */
    public FakeEventQuestionDao with(final EventQuestion question) {
        questions.put(question.getId(), question);
        nextId = Math.max(nextId, question.getId() + 1);
        return this;
    }

    /** La pregunta guardada con ese id, o null si no hay. */
    public EventQuestion stored(final long id) {
        return questions.get(id);
    }

    public int size() {
        return questions.size();
    }

}
