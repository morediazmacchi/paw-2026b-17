package ar.edu.itba.paw.services;

import ar.edu.itba.paw.model.User;
import ar.edu.itba.paw.persistence.UserDao;
import java.util.*;

/**
 * UserDao "de mentira" en memoria para los tests de services.
 * Guarda los User en un mapa; las escrituras modifican el User guardado.
 * Fake escrito a mano (Sotuyo, clase de testing): se prueba por el ESTADO que queda,
 * sin Mockito. Lo que el service no usa tira UnsupportedOperationException.
 */
public class FakeUserDao implements UserDao {

    private final Map<Long, User> users = new LinkedHashMap<>();
    private final Map<Long, Set<String>> roles = new HashMap<>();
    private final Map<Long, Boolean> suspendedFlags = new HashMap<>();
    private long nextId = 1;

    @Override
    public User create(final User user) {
        user.setId(nextId++);
        users.put(user.getId(), user);
        return user;
    }

    @Override
    public Optional<User> findById(final long id) {
        return Optional.ofNullable(users.get(id));
    }

    @Override
    public Optional<User> findByEmail(final String email) {
        for (final User user : users.values()) {
            if (user.getEmail().equals(email)) {
                return Optional.of(user);
            }
        }
        return Optional.empty();
    }

    @Override
    public List<User> findAll() {
        return new ArrayList<>(users.values());
    }

    @Override
    public List<User> findByIds(final List<Long> ids) {
        final List<User> result = new ArrayList<>();
        for (final Long id : ids) {
            final User user = stored(id);
            if (user != null) {
                result.add(user);
            }
        }
        return result;
    }

    @Override
    public Set<String> findRoles(final long userId) {
        return roles.getOrDefault(userId, new HashSet<>());
    }

    @Override
    public void addRole(final long userId, final String role) {
        roles.computeIfAbsent(userId, k -> new HashSet<>()).add(role);
    }

    @Override
    public void removeRole(final long userId, final String role) {
        roles.computeIfAbsent(userId, k -> new HashSet<>()).remove(role);
    }

    @Override
    public void setPassword(final long userId, final String passwordHash) {
        if (users.containsKey(userId)) {
            users.get(userId).setPassword(passwordHash);
        }
    }

    @Override
    public void updateProfile(final long userId, final String name, final String email) {
        if (users.containsKey(userId)) {
            users.get(userId).setName(name);
            users.get(userId).setEmail(email);
        }
    }

    @Override
    public void setVerified(final long userId, final boolean verified) {
        if (users.containsKey(userId)) {
            users.get(userId).setVerified(verified);
        }
    }

    @Override
    public void setLocale(final long userId, final String locale) {
        if (users.containsKey(userId)) {
            users.get(userId).setLocale(locale);
        }
    }

    @Override
    public void setSuspended(final long userId, final boolean suspended) {
        suspendedFlags.put(userId, suspended);
        if (users.containsKey(userId)) {
            users.get(userId).setSuspended(suspended);
        }
    }

    /** Arma el estado inicial: un usuario que "ya estaba en la base". */
    public FakeUserDao with(final User user) {
        users.put(user.getId(), user);
        nextId = Math.max(nextId, user.getId() + 1);
        return this;
    }

    /** El usuario tal como quedo guardado (o null si no existe). */
    public User stored(final long id) {
        return users.get(id);
    }

    /** Cuantos usuarios hay guardados. */
    public int size() {
        return users.size();
    }

    /** Roles que quedaron para ese usuario. */
    public Set<String> rolesOf(final long userId) {
        return roles.getOrDefault(userId, new HashSet<>());
    }

    /** Ultimo valor con que se pidio suspender/reactivar a ese id (null si nunca), exista o no el usuario. */
    public Boolean suspendedFlagOf(final long userId) {
        return suspendedFlags.get(userId);
    }

}
