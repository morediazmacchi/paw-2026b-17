package ar.edu.itba.paw.services;

import ar.edu.itba.paw.model.Registration;
import ar.edu.itba.paw.model.User;
import java.util.*;

/**
 * RegistrationService "de mentira" en memoria para los tests de services.
 * Devuelve las inscripciones que se le dejaron con with(); anota los promoteFromWaitlist().
 * Fake escrito a mano (Sotuyo, clase de testing): se prueba por el ESTADO que queda,
 * sin Mockito. Lo que el service no usa tira UnsupportedOperationException.
 */
public class FakeRegistrationService implements RegistrationService {

    private final List<Registration> registrations = new ArrayList<>();
    private final List<Long> promotedEvents = new ArrayList<>();
    private long occupied;

    @Override
    public RegistrationResult register(final long eventId, final User user) {
        throw new UnsupportedOperationException("register: este fake no lo implementa");
    }

    @Override
    public boolean isFull(final long eventId) {
        throw new UnsupportedOperationException("isFull: este fake no lo implementa");
    }

    @Override
    public boolean isFullFor(final long eventId, final long userId) {
        throw new UnsupportedOperationException("isFullFor: este fake no lo implementa");
    }

    @Override
    public Integer availableSpots(final long eventId) {
        throw new UnsupportedOperationException("availableSpots: este fake no lo implementa");
    }

    @Override
    public long occupiedSpots(final long eventId) {
        return occupied;
    }

    @Override
    public List<Registration> findByUserId(final long userId) {
        throw new UnsupportedOperationException("findByUserId: este fake no lo implementa");
    }

    @Override
    public UnregisterResult cancel(final long registrationId, final long userId) {
        throw new UnsupportedOperationException("cancel: este fake no lo implementa");
    }

    @Override
    public Optional<Registration> findByEventAndUserId(final long eventId, final long userId) {
        for (final Registration registration : registrations) {
            if (registration.getEventId() == eventId && Long.valueOf(userId).equals(registration.getUserId())) {
                return Optional.of(registration);
            }
        }
        return Optional.empty();
    }

    @Override
    public List<Registration> findByEventId(final long eventId) {
        final List<Registration> result = new ArrayList<>();
        for (final Registration registration : registrations) {
            if (registration.getEventId() == eventId) {
                result.add(registration);
            }
        }
        return result;
    }

    @Override
    public List<Registration> findPendingByEvent(final long eventId, final long creatorId) {
        throw new UnsupportedOperationException("findPendingByEvent: este fake no lo implementa");
    }

    @Override
    public ApprovalResult approve(final long registrationId, final long creatorId) {
        throw new UnsupportedOperationException("approve: este fake no lo implementa");
    }

    @Override
    public boolean reject(final long registrationId, final long creatorId) {
        throw new UnsupportedOperationException("reject: este fake no lo implementa");
    }

    @Override
    public boolean revoke(final long registrationId, final long creatorId) {
        throw new UnsupportedOperationException("revoke: este fake no lo implementa");
    }

    @Override
    public int promoteFromWaitlist(final long eventId) {
        promotedEvents.add(eventId);
        return 0;
    }

    /** Deja una inscripcion guardada. */
    public FakeRegistrationService with(final Registration registration) {
        registrations.add(registration);
        return this;
    }

    /** Cuantos lugares dice ocupar cualquier evento (confirmados + pendientes + invitaciones). */
    public FakeRegistrationService occupying(final long spots) {
        this.occupied = spots;
        return this;
    }

    /** Ids de los eventos para los que se pidio promover la lista de espera, en orden. */
    public List<Long> promotedEvents() {
        return promotedEvents;
    }

}
