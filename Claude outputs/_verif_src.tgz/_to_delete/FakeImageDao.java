package ar.edu.itba.paw.services;

import ar.edu.itba.paw.model.Image;
import ar.edu.itba.paw.persistence.ImageDao;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

/**
 * ImageDao "de mentira" en memoria para los tests de services.
 * Guarda las imagenes en un mapa y les asigna el id como lo hace la base.
 * Fake escrito a mano (Sotuyo, clase de testing): se prueba por el ESTADO que queda,
 * sin Mockito.
 */
public class FakeImageDao implements ImageDao {

    private final Map<Long, Image> images = new LinkedHashMap<>();
    private long nextId = 1;

    @Override
    public Image create(final Image image) {
        image.setId(nextId++);
        images.put(image.getId(), image);
        return image;
    }

    @Override
    public Optional<Image> findById(final long id) {
        return Optional.ofNullable(images.get(id));
    }

    /** Deja una imagen ya guardada (con su id), como si estuviera en la base. */
    public FakeImageDao with(final Image image) {
        images.put(image.getId(), image);
        return this;
    }

    /** La imagen guardada con ese id, o null si no hay. */
    public Image stored(final long id) {
        return images.get(id);
    }

    public int size() {
        return images.size();
    }
}
