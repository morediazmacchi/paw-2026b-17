package ar.edu.itba.paw.services;

import ar.edu.itba.paw.model.User;
import ar.edu.itba.paw.services.UserService;
import java.util.*;

/**
 * UserService "de mentira" en memoria para los tests de services.
 * Solo implementa suspend (anota cada pedido).
 * Fake escrito a mano (Sotuyo, clase de testing): se prueba por el ESTADO que queda,
 * sin Mockito. Lo que el service no usa tira UnsupportedOperationException.
 */
public class FakeUserService implements UserService {

    private final List<Long> suspended = new ArrayList<>();

    @Override
    public Optional<User> findById(final long id) {
        throw new UnsupportedOperationException("findById: este fake no lo implementa");
    }

    @Override
    public List<User> findByIds(final List<Long> ids) {
        throw new UnsupportedOperationException("findByIds: este fake no lo implementa");
    }

    @Override
    public List<User> findAll() {
        throw new UnsupportedOperationException("findAll: este fake no lo implementa");
    }

    @Override
    public User findOrCreate(final String email, final String name) {
        throw new UnsupportedOperationException("findOrCreate: este fake no lo implementa");
    }

    @Override
    public Optional<User> findByEmail(final String email) {
        throw new UnsupportedOperationException("findByEmail: este fake no lo implementa");
    }

    @Override
    public UserRegistrationResult register(final String email, final String name, final String rawPassword, final String redirectAfterConfirm) {
        throw new UnsupportedOperationException("register: este fake no lo implementa");
    }

    @Override
    public Optional<User> confirmEmail(final String token) {
        throw new UnsupportedOperationException("confirmEmail: este fake no lo implementa");
    }

    @Override
    public void resendVerificationEmail(final String email) {
        throw new UnsupportedOperationException("resendVerificationEmail: este fake no lo implementa");
    }

    @Override
    public void sendPasswordResetEmail(final String email) {
        throw new UnsupportedOperationException("sendPasswordResetEmail: este fake no lo implementa");
    }

    @Override
    public boolean isResetTokenValid(final String token) {
        throw new UnsupportedOperationException("isResetTokenValid: este fake no lo implementa");
    }

    @Override
    public PasswordResetResult resetPassword(final String token, final String newPassword) {
        throw new UnsupportedOperationException("resetPassword: este fake no lo implementa");
    }

    @Override
    public ProfileUpdateResult updateProfile(final long userId, final String name, final String email) {
        throw new UnsupportedOperationException("updateProfile: este fake no lo implementa");
    }

    @Override
    public boolean changePassword(final long userId, final String currentPassword, final String newPassword) {
        throw new UnsupportedOperationException("changePassword: este fake no lo implementa");
    }

    @Override
    public void updateLocale(final long userId, final String locale) {
        throw new UnsupportedOperationException("updateLocale: este fake no lo implementa");
    }

    @Override
    public void suspend(final long userId) {
        suspended.add(userId);
    }

    @Override
    public void reactivate(final long userId) {
        throw new UnsupportedOperationException("reactivate: este fake no lo implementa");
    }

    @Override
    public void grantAdmin(final long userId) {
        throw new UnsupportedOperationException("grantAdmin: este fake no lo implementa");
    }

    @Override
    public void revokeAdmin(final long userId) {
        throw new UnsupportedOperationException("revokeAdmin: este fake no lo implementa");
    }

    /** Ids de los usuarios a los que se pidio suspender, en orden. */
    public List<Long> suspended() {
        return suspended;
    }

}
