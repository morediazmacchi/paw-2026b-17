# Manda los mails que genero Thymeleaf, usando las credenciales del mail.properties.
import smtplib, ssl, io, sys
from email.message import EmailMessage

d={}
for line in io.open('services/src/main/resources/mail.properties',encoding='utf-8'):
    line=line.strip()
    if line and not line.startswith('#') and '=' in line:
        k,v=line.split('=',1); d[k.strip()]=v.strip()
user=d['mail.username']; pwd=d['mail.password']

MAILS=[
 ("event-created_es.html",          "[es] Tu evento \"Peña en Villa Crespo\" ya está publicado"),
 ("registration-confirmed_es.html", "[es] Confirmamos tu lugar en \"Peña en Villa Crespo\""),
 ("new-registration_es.html",       "[es] Alguien más se sumó a \"Peña en Villa Crespo\""),
 ("event-created_en.html",          "[en] Your event \"Peña en Villa Crespo\" is now live"),
]

s=smtplib.SMTP(d['mail.host'], int(d['mail.port']), timeout=30)
s.ehlo(); s.starttls(context=ssl.create_default_context()); s.ehlo(); s.login(user,pwd)
for fname, subject in MAILS:
    html=io.open('_to_delete/render/'+fname,encoding='utf-8').read()
    m=EmailMessage()
    m['From']="Plancito <%s>"%user; m['To']=user; m['Subject']=subject
    m.set_content("Tu cliente de mail no muestra HTML.")
    m.add_alternative(html, subtype='html')
    s.send_message(m); print("enviado:", subject)
s.quit()
print("LISTO: 4 mails enviados a", user)
