# Lee las credenciales del propio mail.properties y prueba el login contra Gmail.
import smtplib, ssl, io, sys
from email.message import EmailMessage

d={}
for line in io.open('services/src/main/resources/mail.properties',encoding='utf-8'):
    line=line.strip()
    if line and not line.startswith('#') and '=' in line:
        k,v=line.split('=',1); d[k.strip()]=v.strip()

host=d['mail.host']; port=int(d['mail.port'])
user=d['mail.username']; pwd=d['mail.password']

print("conectando a %s:%s ..." % (host,port)); sys.stdout.flush()
try:
    s=smtplib.SMTP(host, port, timeout=25)
except Exception as e:
    print("NO SE PUDO CONECTAR (red bloqueada o servidor inalcanzable):", type(e).__name__, e); raise SystemExit(2)
print("conectado. iniciando STARTTLS ..."); sys.stdout.flush()
s.ehlo(); s.starttls(context=ssl.create_default_context()); s.ehlo()
print("TLS ok. probando login ..."); sys.stdout.flush()
try:
    s.login(user, pwd)
except smtplib.SMTPAuthenticationError as e:
    print("LOGIN RECHAZADO ->", e.smtp_code, e.smtp_error.decode('utf-8','replace')); raise SystemExit(3)
print("LOGIN OK")

m=EmailMessage()
m['From']="Plancito <%s>" % user
m['To']=user
m['Subject']="Prueba de Plancito: el SMTP funciona"
m.set_content("Si estás leyendo esto, las credenciales andan.")
m.add_alternative("<html><body><h2>¡Funciona!</h2>"
                  "<p>Las credenciales SMTP de Plancito están bien configuradas.</p>"
                  "<p><a href=\"http://localhost:8080/eventos\">Ver eventos</a></p>"
                  "</body></html>", subtype='html')
s.send_message(m); s.quit()
print("MAIL ENVIADO a", user)
