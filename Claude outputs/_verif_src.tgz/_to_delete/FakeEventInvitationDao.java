package ar.edu.itba.paw.services;

import ar.edu.itba.paw.model.EventInvitation;
import ar.edu.itba.paw.persistence.EventInvitationDao;
import java.util.*;

/**
 * EventInvitationDao "de mentira" en memoria para los tests de services.
 * Solo implementa linkUserId (es lo unico que usa UserServiceImpl): anota cada pedido.
 * Fake escrito a mano (Sotuyo, clase de testing): se prueba por el ESTADO que queda,
 * sin Mockito. Lo que el service no usa tira UnsupportedOperationException.
 */
public class FakeEventInvitationDao implements EventInvitationDao {

    private final List<Object[]> linkRequests = new ArrayList<>();

    @Override
    public EventInvitation create(final EventInvitation invitation) {
        throw new UnsupportedOperationException("create: este fake no lo implementa");
    }

    @Override
    public Optional<EventInvitation> findByEventAndEmail(final long eventId, final String email) {
        throw new UnsupportedOperationException("findByEventAndEmail: este fake no lo implementa");
    }

    @Override
    public Optional<EventInvitation> findByEventAndUserId(final long eventId, final long userId) {
        throw new UnsupportedOperationException("findByEventAndUserId: este fake no lo implementa");
    }

    @Override
    public long countOutstanding(final long eventId) {
        throw new UnsupportedOperationException("countOutstanding: este fake no lo implementa");
    }

    @Override
    public void deleteByEventAndEmail(final long eventId, final String email) {
        throw new UnsupportedOperationException("deleteByEventAndEmail: este fake no lo implementa");
    }

    @Override
    public List<EventInvitation> findByEvent(final long eventId) {
        throw new UnsupportedOperationException("findByEvent: este fake no lo implementa");
    }

    @Override
    public List<EventInvitation> findByUserId(final long userId) {
        throw new UnsupportedOperationException("findByUserId: este fake no lo implementa");
    }

    @Override
    public void linkUserId(final String email, final long userId) {
        linkRequests.add(new Object[] {email, userId});
    }

    /** Pedidos de linkUserId(email, userId) recibidos, en orden (cada uno: {email, userId}). */
    public List<Object[]> linkRequests() {
        return linkRequests;
    }

}
