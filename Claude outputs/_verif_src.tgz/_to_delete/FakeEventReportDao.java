package ar.edu.itba.paw.services;

import ar.edu.itba.paw.model.EventReport;
import ar.edu.itba.paw.model.ReportStatus;
import ar.edu.itba.paw.persistence.EventReportDao;
import java.util.*;

/**
 * EventReportDao "de mentira" en memoria para los tests de services.
 * Guarda los reportes en una lista; las escrituras modifican el reporte guardado igual que el UPDATE real.
 * Fake escrito a mano (Sotuyo, clase de testing): se prueba por el ESTADO que queda,
 * sin Mockito. Lo que el service no usa tira UnsupportedOperationException.
 */
public class FakeEventReportDao implements EventReportDao {

    private final List<EventReport> reports = new ArrayList<>();
    private long nextId = 1;

    @Override
    public EventReport create(final EventReport report) {
        report.setId(nextId++);
        reports.add(report);
        return report;
    }

    @Override
    public Optional<EventReport> findById(final long id) {
        for (final EventReport report : reports) {
            if (report.getId() == id) {
                return Optional.of(report);
            }
        }
        return Optional.empty();
    }

    @Override
    public List<EventReport> findPending() {
        final List<EventReport> result = new ArrayList<>();
        for (final EventReport report : reports) {
            if (report.isPending()) {
                result.add(report);
            }
        }
        return result;
    }

    @Override
    public List<EventReport> findChangesRequested() {
        final List<EventReport> result = new ArrayList<>();
        for (final EventReport report : reports) {
            if (report.getStatus() == ReportStatus.CHANGES_REQUESTED) {
                result.add(report);
            }
        }
        return result;
    }

    @Override
    public boolean existsPendingByEventAndReporter(final long eventId, final long reporterUserId) {
        for (final EventReport report : reports) {
            if (report.isPending() && report.getEventId() == eventId && report.getReporterUserId() == reporterUserId) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void requestChanges(final long reportId, final String message, final long adminUserId) {
        for (final EventReport report : reports) {
            if (report.getId() == reportId && report.isPending()) {
                report.setStatus(ReportStatus.CHANGES_REQUESTED);
                report.setChangesRequestedMessage(message);
                report.setChangesRequestedByUserId(adminUserId);
            }
        }
    }

    @Override
    public void resolve(final long reportId, final ReportStatus status, final long resolvedByUserId) {
        for (final EventReport report : reports) {
            if (report.getId() == reportId && report.isOpen()) {
                report.setStatus(status);
                report.setResolvedByUserId(resolvedByUserId);
            }
        }
    }

    @Override
    public void resolveAllPendingForEvent(final long eventId, final ReportStatus status, final long resolvedByUserId) {
        for (final EventReport report : reports) {
            if (report.getEventId() == eventId && report.isOpen()) {
                report.setStatus(status);
                report.setResolvedByUserId(resolvedByUserId);
            }
        }
    }

    /** Arma el estado inicial: un reporte que "ya estaba en la base" (conserva su id). */
    public FakeEventReportDao with(final EventReport report) {
        reports.add(report);
        nextId = Math.max(nextId, report.getId() + 1);
        return this;
    }

    /** Los reportes guardados, tal como quedaron. */
    public List<EventReport> all() {
        return reports;
    }

}
