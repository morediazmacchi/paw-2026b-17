package ar.edu.itba.paw.services;

import ar.edu.itba.paw.persistence.FavoriteDao;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

/**
 * FavoriteDao "de mentira" en memoria para los tests de services.
 * Guarda los pares (usuario, evento) en un conjunto: agregar dos veces el mismo
 * favorito no lo duplica, igual que la clave unica de la tabla real.
 * Fake escrito a mano (Sotuyo, clase de testing): se prueba por el ESTADO que queda,
 * sin Mockito.
 */
public class FakeFavoriteDao implements FavoriteDao {

    private final Set<String> favorites = new LinkedHashSet<>();

    private static String key(final long userId, final long eventId) {
        return userId + ":" + eventId;
    }

    @Override
    public void add(final long userId, final long eventId) {
        favorites.add(key(userId, eventId));
    }

    @Override
    public void remove(final long userId, final long eventId) {
        favorites.remove(key(userId, eventId));
    }

    @Override
    public boolean isFavorite(final long userId, final long eventId) {
        return favorites.contains(key(userId, eventId));
    }

    @Override
    public List<Long> findEventIdsByUser(final long userId) {
        final List<Long> eventIds = new ArrayList<>();
        for (final String favorite : favorites) {
            final String[] parts = favorite.split(":");
            if (Long.parseLong(parts[0]) == userId) {
                eventIds.add(Long.parseLong(parts[1]));
            }
        }
        return eventIds;
    }
}
