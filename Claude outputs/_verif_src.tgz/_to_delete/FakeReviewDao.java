package ar.edu.itba.paw.services;

import ar.edu.itba.paw.model.Review;
import ar.edu.itba.paw.persistence.ReviewDao;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

/**
 * ReviewDao "de mentira" en memoria para los tests de services.
 * Guarda las resenias en una lista. Como la tabla real, no sabe quien creo cada
 * evento (eso lo resuelve el JOIN con event): por eso las resenias que se dejan ya
 * guardadas llevan el id del creador del evento, con withReviewOfCreator().
 * Fake escrito a mano (Sotuyo, clase de testing): se prueba por el ESTADO que queda,
 * sin Mockito.
 */
public class FakeReviewDao implements ReviewDao {

    private final Map<Review, Long> creatorOfEachReview = new LinkedHashMap<>();
    private long nextId = 1;
    private RuntimeException createFailure;

    @Override
    public Review create(final Review review) {
        if (createFailure != null) {
            throw createFailure;
        }
        review.setId(nextId++);
        creatorOfEachReview.put(review, null);
        return review;
    }

    @Override
    public Optional<Review> findByEventAndUser(final long eventId, final long userId) {
        for (final Review review : creatorOfEachReview.keySet()) {
            if (review.getEventId() == eventId && review.getUserId() == userId) {
                return Optional.of(review);
            }
        }
        return Optional.empty();
    }

    @Override
    public List<Review> findByCreatorId(final long creatorId) {
        final List<Review> result = new ArrayList<>();
        for (final Map.Entry<Review, Long> entry : creatorOfEachReview.entrySet()) {
            if (Long.valueOf(creatorId).equals(entry.getValue())) {
                result.add(0, entry.getKey()); // la mas nueva primero
            }
        }
        return result;
    }

    @Override
    public double findAverageRatingByCreatorId(final long creatorId) {
        final List<Review> reviews = findByCreatorId(creatorId);
        if (reviews.isEmpty()) {
            return 0;
        }
        double sum = 0;
        for (final Review review : reviews) {
            sum += review.getRating();
        }
        return sum / reviews.size();
    }

    /** Deja una resenia ya guardada de un evento cuyo creador es creatorId. */
    public FakeReviewDao withReviewOfCreator(final Review review, final long creatorId) {
        review.setId(nextId++);
        creatorOfEachReview.put(review, creatorId);
        return this;
    }

    /** Hace que create() falle como falla la base (por ejemplo, clave unica evento+usuario). */
    public FakeReviewDao failingCreateWith(final RuntimeException failure) {
        this.createFailure = failure;
        return this;
    }

    /** Las resenias guardadas, en orden. */
    public List<Review> all() {
        return new ArrayList<>(creatorOfEachReview.keySet());
    }
}
